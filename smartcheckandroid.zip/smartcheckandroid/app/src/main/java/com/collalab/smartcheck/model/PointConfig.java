package com.collalab.smartcheck.model;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class PointConfig implements Serializable {

    @SerializedName("check_point")
    @Expose
    private String checkPoint;
    @SerializedName("share_point")
    @Expose
    private String sharePoint;
    @SerializedName("ref_point")
    @Expose
    private String refPoint;
    @SerializedName("time_point")
    @Expose
    private String timePoint;

    /**
     * No args constructor for use in serialization
     */
    public PointConfig() {
    }

    /**
     * @param timePoint
     * @param checkPoint
     * @param sharePoint
     * @param refPoint
     */
    public PointConfig(String checkPoint, String sharePoint, String refPoint, String timePoint) {
        super();
        this.checkPoint = checkPoint;
        this.sharePoint = sharePoint;
        this.refPoint = refPoint;
        this.timePoint = timePoint;
    }

    public String getCheckPoint() {
        return checkPoint;
    }

    public void setCheckPoint(String checkPoint) {
        this.checkPoint = checkPoint;
    }

    public String getSharePoint() {
        return sharePoint;
    }

    public void setSharePoint(String sharePoint) {
        this.sharePoint = sharePoint;
    }

    public String getRefPoint() {
        return refPoint;
    }

    public void setRefPoint(String refPoint) {
        this.refPoint = refPoint;
    }

    public String getTimePoint() {
        return timePoint;
    }

    public void setTimePoint(String timePoint) {
        this.timePoint = timePoint;
    }

}

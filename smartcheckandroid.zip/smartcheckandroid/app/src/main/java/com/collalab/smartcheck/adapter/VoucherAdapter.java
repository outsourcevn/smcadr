package com.collalab.smartcheck.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.collalab.smartcheck.R;
import com.collalab.smartcheck.common.Constant;
import com.collalab.smartcheck.model.Voucher;
import com.squareup.picasso.Picasso;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class VoucherAdapter extends RecyclerView.Adapter<VoucherAdapter.VoucherViewHolder> {

    private List<Voucher> voucherList;
    private Context mContext;

    public void setOnVoucherItemListener(OnVoucherItemListener onVoucherItemListener) {
        this.onVoucherItemListener = onVoucherItemListener;
    }

    OnVoucherItemListener onVoucherItemListener;

    public interface OnVoucherItemListener {
        void onClick(int position);

        void onBuy(int position);
    }

    public class VoucherViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.btn_favorite)
        ImageView btnFavorite;
        @BindView(R.id.img_voucher)
        ImageView imgVoucher;
        @BindView(R.id.tv_voucher)
        TextView tvVoucher;
        @BindView(R.id.tv_point_price)
        TextView tvVoucherPrice;
        @BindView(R.id.btn_buy_reward)
        View btnBuyReward;

        public VoucherViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }
    }

    public VoucherAdapter(Context context, List<Voucher> voucherList) {
        this.mContext = context;
        this.voucherList = voucherList;
    }

    @Override
    public VoucherViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_voucher_item, parent, false);

        return new VoucherViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(VoucherViewHolder holder, final int position) {

        Voucher voucher = voucherList.get(position);

        if (!TextUtils.isEmpty(voucher.getName())) {
            holder.tvVoucher.setText(voucher.getName());
        }

        if (voucher.getPoint() != null) {
            holder.tvVoucherPrice.setText(String.valueOf(voucher.getPoint()) + " " + mContext.getResources().getString(R.string.string_voucher_point));
        }

        if (!TextUtils.isEmpty(voucher.getImage())) {
            String voucherUrl = Constant.HOST_NAME + voucher.getImage();
            Picasso.with(mContext).load(voucherUrl).placeholder(R.drawable.no_image_holder).error(R.drawable.no_image_holder).into(holder.imgVoucher);
        }

        holder.btnBuyReward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onVoucherItemListener != null) {
                    onVoucherItemListener.onBuy(position);
                }
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onVoucherItemListener != null) {
                    onVoucherItemListener.onClick(position);
                }
            }
        });

    }

    public void setVoucherList(List<Voucher> voucherList) {
        this.voucherList = voucherList;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return voucherList == null ? 0 : voucherList.size();
    }
}
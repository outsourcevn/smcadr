package com.collalab.smartcheck.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Prize {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("winning_id")
    @Expose
    private Integer winningId;
    @SerializedName("winning_name")
    @Expose
    private String winningName;
    @SerializedName("money")
    @Expose
    private String money;
    @SerializedName("user_id")
    @Expose
    private Integer userId;
    @SerializedName("user_name")
    @Expose
    private String userName;
    @SerializedName("user_email")
    @Expose
    private String userEmail;
    @SerializedName("user_phone")
    @Expose
    private String userPhone;
    @SerializedName("date_time")
    @Expose
    private String dateTime;
    @SerializedName("lon")
    @Expose
    private Float lon;
    @SerializedName("lat")
    @Expose
    private Float lat;
    @SerializedName("address")
    @Expose
    private String address;
    @SerializedName("qrcode")
    @Expose
    private String qrcode;

    /**
     * No args constructor for use in serialization
     */
    public Prize() {
    }

    /**
     * @param winningName
     * @param lon
     * @param winningId
     * @param dateTime
     * @param userEmail
     * @param id
     * @param address
     * @param qrcode
     * @param userId
     * @param money
     * @param userName
     * @param userPhone
     * @param lat
     */
    public Prize(Integer id, Integer winningId, String winningName, String money, Integer userId, String userName, String userEmail, String userPhone, String dateTime, Float lon, Float lat, String address, String qrcode) {
        super();
        this.id = id;
        this.winningId = winningId;
        this.winningName = winningName;
        this.money = money;
        this.userId = userId;
        this.userName = userName;
        this.userEmail = userEmail;
        this.userPhone = userPhone;
        this.dateTime = dateTime;
        this.lon = lon;
        this.lat = lat;
        this.address = address;
        this.qrcode = qrcode;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getWinningId() {
        return winningId;
    }

    public void setWinningId(Integer winningId) {
        this.winningId = winningId;
    }

    public String getWinningName() {
        return winningName;
    }

    public void setWinningName(String winningName) {
        this.winningName = winningName;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public Float getLon() {
        return lon;
    }

    public void setLon(Float lon) {
        this.lon = lon;
    }

    public Float getLat() {
        return lat;
    }

    public void setLat(Float lat) {
        this.lat = lat;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getQrcode() {
        return qrcode;
    }

    public void setQrcode(String qrcode) {
        this.qrcode = qrcode;
    }

}

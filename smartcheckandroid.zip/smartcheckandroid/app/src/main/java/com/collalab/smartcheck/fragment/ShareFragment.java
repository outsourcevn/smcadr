package com.collalab.smartcheck.fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.collalab.smartcheck.R;
import com.collalab.smartcheck.common.Constant;
import com.collalab.smartcheck.event.EventFacebookAvatar;
import com.collalab.smartcheck.listener.OnChangePointListener;
import com.collalab.smartcheck.model.BonusPoint;
import com.collalab.smartcheck.model.PointConfig;
import com.collalab.smartcheck.model.UserInfo;
import com.collalab.smartcheck.persistence.PreferenceUtils;
import com.collalab.smartcheck.persistence.PrefsKey;
import com.collalab.smartcheck.utils.DataParser;
import com.collalab.smartcheck.utils.StringStyleUtils;
import com.crashlytics.android.answers.Answers;
import com.crashlytics.android.answers.ShareEvent;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.HttpMethod;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.facebook.share.Sharer;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.ShareOpenGraphAction;
import com.facebook.share.model.ShareOpenGraphContent;
import com.facebook.share.model.ShareOpenGraphObject;
import com.facebook.share.widget.ShareDialog;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONObject;

import java.util.Arrays;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ShareFragment extends BaseFragment {

    OnChangePointListener mOnChangePointListener;
    CallbackManager callbackManager;
    ShareDialog shareDialog;

    UserInfo mUserInfo;
    PointConfig mPointConfig;

    @BindView(R.id.login_button)
    LoginButton mLoginButton;
    @BindView(R.id.layout_login)
    View mLayoutLogin;
    @BindView(R.id.layout_share)
    View mLayoutShare;
    @BindView(R.id.btn_login_facebook)
    View mBtnLoginFacebookFake;

    boolean hasRequestRealLogin = false;

    public ShareFragment() {

    }

    public static ShareFragment newInstance() {
        ShareFragment fragment = new ShareFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mUserInfo = DataParser.getUserInfo(PreferenceUtils.getString(PrefsKey.KEY_USER_INFO, null));
        mPointConfig = DataParser.parsePointConfig(PreferenceUtils.getString(PrefsKey.KEY_POINT_CONFIG, null));

    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_share, container, false);
        ButterKnife.bind(this, view);

        callbackManager = CallbackManager.Factory.create();
        shareDialog = new ShareDialog(this);
        shareDialog.registerCallback(callbackManager, mResultFacebookCallback);

        mLoginButton.setFragment(this);
        mLoginButton.registerCallback(callbackManager, mLoginResultCallBack);

        if (AccessToken.getCurrentAccessToken() != null /*&& AccessToken.getCurrentAccessToken().getPermissions().contains("publish_actions")*/) {
            mLayoutLogin.setVisibility(View.GONE);
            mLayoutShare.setVisibility(View.VISIBLE);
        }

        return view;
    }

    @OnClick(R.id.layout_share_facebook)
    public void onShareFacebook() {
        doShareFacebook();
    }

    @OnClick(R.id.btn_login_facebook)
    public void onFakeLoginFacebookClick() {
/*        if (AccessToken.getCurrentAccessToken() != null && !AccessToken.getCurrentAccessToken().getPermissions().contains("publish_actions")) {
            doRequestPublishActionPermission();
        } else {*/
        mLoginButton.performClick();
       /* }*/
    }

    public void setOnChangePointListener(OnChangePointListener onChangePointListener) {
        this.mOnChangePointListener = onChangePointListener;
    }

    private void doShareFacebook() {

        if (ShareDialog.canShow(ShareLinkContent.class)) {
            ShareLinkContent linkContent = new ShareLinkContent.Builder()
                    .setContentUrl(Uri.parse(Constant.SMARTCHECK_STORE_URL))
                    .build();
            shareDialog.show(linkContent, ShareDialog.Mode.AUTOMATIC);
        }

    }

    public void doRequestPublishActionPermission() {
        LoginManager.getInstance().logInWithPublishPermissions(ShareFragment.this, Arrays.asList("publish_actions"));
    }

    FacebookCallback<LoginResult> mLoginResultCallBack = new FacebookCallback<LoginResult>() {

        @Override
        public void onSuccess(LoginResult loginResult) {

            getAndSaveFacebookAvatarLink();

/*            if (loginResult.getRecentlyGrantedPermissions() != null && !loginResult.getRecentlyGrantedPermissions().contains("publish_actions")) {
                doRequestPublishActionPermission();
            } else {*/
                mLayoutLogin.setVisibility(View.GONE);
            mLayoutShare.setVisibility(View.VISIBLE);
            /*}*/

//            if (loginResult.getRecentlyGrantedPermissions() != null && loginResult.getRecentlyGrantedPermissions().contains("publish_actions")) {
//                mLayoutLogin.setVisibility(View.GONE);
//                mLayoutShare.setVisibility(View.VISIBLE);
//            } else {
//                if (!hasRequestRealLogin) {
//                    hasRequestRealLogin = true;
//                    LoginManager.getInstance().logInWithPublishPermissions(ShareFragment.this, Arrays.asList("publish_actions"));
//                }
//                mLayoutLogin.setVisibility(View.VISIBLE);
//                mLayoutShare.setVisibility(View.GONE);
//            }

        }

        @Override
        public void onCancel() {
            Log.i("Login", "Login Cancel");
        }

        @Override
        public void onError(FacebookException error) {
            Log.i("Login", "Login Error");
        }
    };

    FacebookCallback<Sharer.Result> mResultFacebookCallback = new FacebookCallback<Sharer.Result>() {
        @Override
        public void onSuccess(Sharer.Result result) {
            Log.i("ShareSmartCheck", "onSuccess");
            if (mUserInfo != null && mPointConfig != null /*&& !TextUtils.isEmpty(result.getPostId())*/) {
                doRewardPoint(mUserInfo.getUserId(), BonusPoint.SHARE_FACEBOOK, mPointConfig.getSharePoint(), mBonusPointCallBack);
            } else {
                showOnCancelShareFb(getResources().getString(R.string.string_share_facebook_cancel));
            }

            Answers.getInstance().logShare(new ShareEvent()
                    .putMethod("Facebook")
                    .putContentName("Share success to Facebook")
                    .putContentType("post")
                    .putContentId((result != null && !TextUtils.isEmpty(result.getPostId())) ? result.getPostId() : "PostID NULL"));
        }

        @Override
        public void onCancel() {
            Log.i("ShareSmartCheck", "onCancel");
            showOnCancelShareFb(getResources().getString(R.string.string_share_facebook_cancel));

            Answers.getInstance().logShare(new ShareEvent()
                    .putMethod("Facebook")
                    .putContentName("Canceled a share to Facebook"));
        }

        @Override
        public void onError(FacebookException error) {
            Log.i("ShareSmartCheck", "onError");
            showErrorMessage(getResources().getString(R.string.string_share_facebook_failed));

            Answers.getInstance().logShare(new ShareEvent()
                    .putMethod("Facebook")
                    .putContentName("Fail when share to Facebook"));
        }
    };

    Callback<String> mBonusPointCallBack = new Callback<String>() {
        @Override
        public void onResponse(Call<String> call, Response<String> response) {

            String totalPoint = DataParser.getTotalPoint(response.body());
            if (!TextUtils.isEmpty(totalPoint)) {
                if (mOnChangePointListener != null) {
                    mOnChangePointListener.onChangePoint(totalPoint);
                }
            }

            showShareFbSuccessDialog();
        }

        @Override
        public void onFailure(Call<String> call, Throwable t) {

        }
    };

    private void showShareFbSuccessDialog() {
        String content = String.format(getResources().getString(R.string.string_share_facebook_bonus_point), mPointConfig.getSharePoint());
        int start = content.indexOf(mPointConfig.getSharePoint());
        int end = start + mPointConfig.getSharePoint().length();
        showShareFacebookSuccess(StringStyleUtils.getBoldElement(content, start, end));
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        callbackManager.onActivityResult(requestCode, resultCode, data);
    }

    private void getAndSaveFacebookAvatarLink() {
        Bundle params = new Bundle();
        params.putString("fields", "id,email,gender,cover,picture.type(large)");
        new GraphRequest(AccessToken.getCurrentAccessToken(), "me", params, HttpMethod.GET,
                new GraphRequest.Callback() {
                    @Override
                    public void onCompleted(GraphResponse response) {
                        if (response != null) {
                            try {
                                JSONObject data = response.getJSONObject();
                                if (data.has("picture")) {
                                    String profilePicUrl = data.getJSONObject("picture").getJSONObject("data").getString("url");
                                    PreferenceUtils.commitString(PrefsKey.KEY_FACEBOOK_AVATAR_LINK, profilePicUrl);
                                    EventFacebookAvatar eventFacebookAvatar = new EventFacebookAvatar();
                                    eventFacebookAvatar.avatarUrl = profilePicUrl;
                                    EventBus.getDefault().post(eventFacebookAvatar);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }).executeAsync();
    }
}
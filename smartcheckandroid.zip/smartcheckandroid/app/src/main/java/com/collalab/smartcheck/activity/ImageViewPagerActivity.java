package com.collalab.smartcheck.activity;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import com.collalab.smartcheck.R;
import com.collalab.smartcheck.common.Constant;
import com.collalab.smartcheck.common.IntentKey;
import com.collalab.smartcheck.widget.HackyViewPager;
import com.github.chrisbanes.photoview.PhotoView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import me.relex.circleindicator.CircleIndicator;


public class ImageViewPagerActivity extends BaseActivity {
    private static final String ISLOCKED_ARG = "isLocked";

    private ViewPager mViewPager;
    ArrayList<String> mListImage;
    private int mSelectedImage;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            boolean isLocked = savedInstanceState.getBoolean(ISLOCKED_ARG, false);
            if (mViewPager != null)
                ((HackyViewPager) mViewPager).setLocked(isLocked);
        }

        setContentView(R.layout.activity_image_view_pager);

        getIntentData();

        CircleIndicator indicator = (CircleIndicator) findViewById(R.id.indicator);
        findViewById(R.id.btn_close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        mViewPager = (HackyViewPager) findViewById(R.id.view_pager);
        mViewPager.setAdapter(new SamplePagerAdapter(this, mListImage));
        indicator.setViewPager(mViewPager);
        mViewPager.setCurrentItem(mSelectedImage);
    }

    private void getIntentData() {
        if (getIntent() != null && getIntent().getExtras() != null && getIntent().getExtras().containsKey(IntentKey.INTENT_KEY_LIST_IMG)) {
            mListImage = getIntent().getExtras().getStringArrayList(IntentKey.INTENT_KEY_LIST_IMG);
        }
        if (getIntent() != null && getIntent().getExtras() != null && getIntent().getExtras().containsKey(IntentKey.INTENT_KEY_IMG_INDEX)) {
            mSelectedImage = getIntent().getExtras().getInt(IntentKey.INTENT_KEY_IMG_INDEX);
        }
    }

    static class SamplePagerAdapter extends PagerAdapter {

        private ArrayList<String> listImagesUrl;
        private Context context;

        public SamplePagerAdapter(Context cont, ArrayList<String> listImagesEntity) {
            this.listImagesUrl = listImagesEntity;
            this.context = cont;
        }

        @Override
        public int getCount() {
            return listImagesUrl.size();
        }

        @Override
        public View instantiateItem(ViewGroup container, int position) {
            final PhotoView photoView;
            if (container.findViewById(position) != null)
                photoView = (PhotoView) container.findViewById(position);
            else
                photoView = new PhotoView(container.getContext());

            Picasso.with(context)
                    .load(Constant.HOST_NAME + listImagesUrl.get(position)).placeholder(R.drawable.no_image_holder)
                    .into(photoView);

            container.addView(photoView, ViewPager.LayoutParams.MATCH_PARENT, ViewPager.LayoutParams.MATCH_PARENT);
            photoView.setId(position);
            return photoView;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

    }

    private boolean isViewPagerActive() {
        return (mViewPager != null && mViewPager instanceof HackyViewPager);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (isViewPagerActive()) {
            outState.putBoolean(ISLOCKED_ARG, ((HackyViewPager) mViewPager).isLocked());
        }
        super.onSaveInstanceState(outState);
    }
}

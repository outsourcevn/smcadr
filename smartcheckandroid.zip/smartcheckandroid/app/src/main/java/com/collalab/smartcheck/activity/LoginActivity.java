package com.collalab.smartcheck.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.collalab.smartcheck.KeyGenerator;
import com.collalab.smartcheck.R;
import com.collalab.smartcheck.model.RequestResponse;
import com.collalab.smartcheck.networking.ApiClient;
import com.collalab.smartcheck.networking.ApiInterface;
import com.collalab.smartcheck.persistence.PreferenceUtils;
import com.collalab.smartcheck.persistence.PrefsKey;
import com.collalab.smartcheck.utils.DataParser;
import com.crashlytics.android.answers.Answers;
import com.crashlytics.android.answers.LoginEvent;

import org.json.JSONObject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends BaseActivity {
    private static final String TAG = "LoginActivity";
    private static final int REQUEST_SIGNUP = 0;

    ApiInterface apiService;

    @BindView(R.id.input_email)
    EditText _phoneText;
    @BindView(R.id.input_password)
    EditText _passwordText;
    @BindView(R.id.btn_login)
    TextView _loginButton;
    @BindView(R.id.link_signup)
    TextView _signupLink;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);

        apiService = ApiClient.getClient().create(ApiInterface.class);

        _loginButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                login();
            }
        });
        _signupLink.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // Start the Signup activity
                Intent intent = new Intent(getApplicationContext(), SignupActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
            }
        });
    }

    public void login() {
        Log.d(TAG, "Login");

        if (!validate()) {
            return;
        }

        buildProgressDialog();
        showLoadingProgress();

        _loginButton.setEnabled(false);

        final String phone = _phoneText.getText().toString();
        final String password = _passwordText.getText().toString();
        Call<String> call = apiService.login(phone, password, String.valueOf(KeyGenerator.generateKey()));
        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                Log.i("SmartCheck", response.body().toString());
                if (!TextUtils.isEmpty(response.body().toString())) {

                    RequestResponse networkRequestResponse = DataParser.getResponse(response.body());

                    if (networkRequestResponse.isSuccess()) {
                        try {
                            JSONObject jsonObject = new JSONObject(response.body().toString());
                            if (jsonObject.has("data") && jsonObject.getJSONArray("data").length() > 0) {
                                JSONObject idObject = (JSONObject) jsonObject.getJSONArray("data").get(0);
                                if (idObject.has("user_id")) {
                                    PreferenceUtils.commitString(PrefsKey.KEY_USER_ID, String.valueOf(idObject.get("user_id")));
                                }
                            }

                            Answers.getInstance().logLogin(new LoginEvent()
                                    .putMethod("Provide phone: " + phone)
                                    .putSuccess(true));

                            PreferenceUtils.commitString(PrefsKey.KEY_USER_PASSWORD, password);

                            PreferenceUtils.commitBoolean(PrefsKey.KEY_IS_LOGGED_IN, true);
                            Intent intent = new Intent(LoginActivity.this, TabActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        } catch (Exception e) {
                            Toast.makeText(LoginActivity.this, getResources().getString(R.string.string_login_failed), Toast.LENGTH_SHORT).show();
                            _loginButton.setEnabled(true);
                        }
                    } else {
                        Answers.getInstance().logLogin(new LoginEvent()
                                .putMethod("Provide phone: " + phone)
                                .putSuccess(false));
                        Toast.makeText(LoginActivity.this, networkRequestResponse.getMessage(), Toast.LENGTH_SHORT).show();
                        _loginButton.setEnabled(true);
                    }

                } else {
                    Answers.getInstance().logLogin(new LoginEvent()
                            .putMethod("Provide phone: " + phone)
                            .putSuccess(false));
                    _loginButton.setEnabled(true);
                    Toast.makeText(LoginActivity.this, getResources().getString(R.string.string_login_failed), Toast.LENGTH_SHORT).show();
                }

                hideLoadingProgress();
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                Answers.getInstance().logLogin(new LoginEvent()
                        .putMethod("Provide phone: " + phone)
                        .putSuccess(false));

                Toast.makeText(LoginActivity.this, getResources().getString(R.string.string_login_failed), Toast.LENGTH_SHORT).show();
                _loginButton.setEnabled(true);
                hideLoadingProgress();
            }
        });
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_SIGNUP) {
            if (resultCode == RESULT_OK) {

                // TODO: Implement successful signup logic here
                // By default we just finish the Activity and log them in automatically
                this.finish();
            }
        }
    }

    public boolean validate() {
        boolean valid = true;

        String phone = _phoneText.getText().toString();
        String password = _passwordText.getText().toString();

        if (phone.isEmpty() || !TextUtils.isDigitsOnly(phone)) {
            _phoneText.setError(getResources().getString(R.string.string_enter_phone));
            valid = false;
        } else {
            _phoneText.setError(null);
        }

        if (password.isEmpty()) {
            _passwordText.setError(getResources().getString(R.string.string_password_validation_msg));
            valid = false;
        } else {
            _passwordText.setError(null);
        }

        return valid;
    }

    @OnClick(R.id.link_forgot_pwd)
    public void onForgotPassword() {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://api.smartcheck.vn/home/reset"));
        startActivity(browserIntent);
    }

}

package com.collalab.smartcheck;

/**
 * Created by laptop88 on 3/27/2017.
 */

public class EventScan {
    public String code;
    public boolean success;
    public boolean isImportProcess;
    public String processType;
    public double lat,lng;
    public String address;
}

package com.collalab.smartcheck.persistence;

/**
 * Created by laptop88 on 12/28/2016.
 */

public class PrefsKey {
    public static String KEY_IS_LOGGED_IN = "key_logged_in";
    public static String KEY_USER_ID = "key_user_id";
    public static String KEY_LOCATION = "key_location";
    public static String KEY_LATITUDE = "key_latitude";
    public static String KEY_LONGITUDE = "key_longitude";
}

package com.collalab.smartcheck.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by laptop88 on 11/5/2017.
 */

public class DateTimeUtils {
    public static String getScannedDateFormattedStr(String date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        SimpleDateFormat outDf = new SimpleDateFormat("HH:mm EEE dd/MM/yyyy");
        Date mCurrentDate = null;
        try {
            mCurrentDate = sdf.parse(date);
            return outDf.format(mCurrentDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String getVoucherDateStr(String date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd hh:mm a");
        SimpleDateFormat outDf = new SimpleDateFormat("dd MMM yyyy");
        Date mCurrentDate = null;
        try {
            mCurrentDate = sdf.parse(date);
            return outDf.format(mCurrentDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String getPrizeDate(String date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a");
        SimpleDateFormat outDf = new SimpleDateFormat("dd MMM yyyy");
        Date mCurrentDate = null;
        try {
            mCurrentDate = sdf.parse(date);
            return outDf.format(mCurrentDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return "";
        }
    }
}

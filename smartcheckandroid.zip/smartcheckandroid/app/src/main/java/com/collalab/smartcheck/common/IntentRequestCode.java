package com.collalab.smartcheck.common;

/**
 * Created by VietMac on 11/4/17.
 */

public class IntentRequestCode {
    public static final int INTENT_EDIT_USER_INFO = 1001;
}

package com.collalab.smartcheck.model;

/**
 * Created by VietMac on 11/6/17.
 */

public class BonusPoint {
    public static final String SHARE_FACEBOOK = "1";
    public static final String USED_MONTH = "2";
}

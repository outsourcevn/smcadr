package com.collalab.smartcheck.persistence;

/**
 * Created by laptop88 on 12/28/2016.
 */

public class PrefsKey {
    public static String KEY_IS_LOGGED_IN = "key_logged_in";
    public static String KEY_USER_ID = "key_user_id";
    public static String KEY_LOCATION = "key_location";
    public static String KEY_LATITUDE = "key_latitude";
    public static String KEY_LONGITUDE = "key_longitude";
    public static String KEY_USER_INFO = "key_user_info";
    public static String KEY_USER_PASSWORD = "key_user_password";
    public static String KEY_POINT_CONFIG = "key_point_config";
    public static String KEY_CURRENT_DATE_REWARD = "key_current_month_reward";
    public static String KEY_FACEBOOK_AVATAR_LINK = "key_facebook_avatar_link";
}

package com.collalab.smartcheck;

/**
 * Created by laptop88 on 8/27/2017.
 */

public class KeyGenerator {
    public static long generateKey() {
        long current_miliseconds = System.currentTimeMillis();
        return current_miliseconds*13 + 27;
    }
}

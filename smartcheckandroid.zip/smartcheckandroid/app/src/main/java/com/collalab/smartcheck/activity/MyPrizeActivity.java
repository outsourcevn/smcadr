package com.collalab.smartcheck.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.collalab.smartcheck.R;
import com.collalab.smartcheck.adapter.PrizeAdapter;
import com.collalab.smartcheck.common.IntentKey;
import com.collalab.smartcheck.model.Prize;
import com.collalab.smartcheck.model.RequestResponse;
import com.collalab.smartcheck.networking.ApiClient;
import com.collalab.smartcheck.networking.ApiInterface;
import com.collalab.smartcheck.persistence.PreferenceUtils;
import com.collalab.smartcheck.persistence.PrefsKey;
import com.collalab.smartcheck.utils.DataParser;

import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MyPrizeActivity extends BaseActivity {

    ApiInterface apiService;
    String mUserId;
    ArrayList<Prize> mPrizeList;
    PrizeAdapter mPrizeAdapter;

    @BindView(R.id.recycler_view)
    RecyclerView mRecyclerView;
    @BindView(R.id.swipe_refresh_layout)
    SwipeRefreshLayout mSwipeRefreshLayout;
    RecyclerView.LayoutManager mLayoutManager;

    @BindView(R.id.layout_empty)
    View mLayoutEmptyList;
    @BindView(R.id.layout_no_network)
    View mLayoutNoNetwork;
    @BindView(R.id.tv_no_connection_cause)
    TextView mTvNotConnectRoot;
    @BindView(R.id.img_no_connection)
    ImageView mImgNotConnectIcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitivity_my_prize);

        ButterKnife.bind(this);
        apiService = ApiClient.getClient().create(ApiInterface.class);
        PreferenceUtils.init(this);

        mUserId = PreferenceUtils.getString(PrefsKey.KEY_USER_ID, null);

        getMyPrizeList_Network();
        setUpRecyclerView();
        setUpSwipeLayout();
    }

    @OnClick(R.id.btn_back)
    public void onBackClick() {
        finish();
    }

    @OnClick(R.id.btn_retry_connect)
    public void onRetryConnect() {
        getMyPrizeList_Network();
    }

    private void setUpRecyclerView() {
        mPrizeAdapter = new PrizeAdapter(this, mPrizeList);
        mPrizeAdapter.setOnPrizeItemListener(onPrizeItemListener);
        mLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mPrizeAdapter);
    }

    private void setUpSwipeLayout() {
        mSwipeRefreshLayout.setColorSchemeColors(ContextCompat.getColor(this, R.color.color_actionbar));
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getMyPrizeList_Network();
            }
        });
    }

    private void hideProgressLoading() {
        if (mSwipeRefreshLayout.isRefreshing()) {
            mSwipeRefreshLayout.setRefreshing(false);
            hideLoadingProgress();
        } else {
            hideLoadingProgress();
        }
    }

    private void getMyPrizeList_Network() {

        if (!mSwipeRefreshLayout.isRefreshing()) {
            buildProgressDialog();
            showLoadingProgress();
        }

        Call<String> call = apiService.getListWinningOfUser(mUserId);
        call.enqueue(mMyPrizeCallBack);
    }

    Callback<String> mMyPrizeCallBack = new Callback<String>() {
        @Override
        public void onResponse(Call<String> call, Response<String> response) {

            mLayoutNoNetwork.setVisibility(View.GONE);

            RequestResponse requestResponse = DataParser.getResponse(response.body());
            if (requestResponse.isSuccess()) {
                mPrizeList = DataParser.parseMyPrizeList(response.body());
                bindMyPrizeList2Views();
            } else {
                Toast.makeText(MyPrizeActivity.this, requestResponse.getMessage(), Toast.LENGTH_SHORT).show();
            }
            hideProgressLoading();
        }

        @Override
        public void onFailure(Call<String> call, Throwable t) {
            hideProgressLoading();
            if (!isNetworkAvailable()) {

                mImgNotConnectIcon.setImageResource(R.drawable.no_network);
                mTvNotConnectRoot.setText(R.string.string_no_network_connection);

                mLayoutNoNetwork.setVisibility(View.VISIBLE);
            } else if (t instanceof SocketTimeoutException || t instanceof UnknownHostException) {

                mImgNotConnectIcon.setImageResource(R.drawable.ic_server_shutdown);
                mTvNotConnectRoot.setText(R.string.string_socket_timeout_exception);

                mLayoutNoNetwork.setVisibility(View.VISIBLE);
            }
        }
    };

    private void bindMyPrizeList2Views() {
        if (mPrizeList != null && mPrizeList.size() > 0) {
            mPrizeAdapter.setPrizeList(mPrizeList);
            mLayoutEmptyList.setVisibility(View.GONE);
        } else {
            mLayoutEmptyList.setVisibility(View.VISIBLE);
        }
    }

    PrizeAdapter.OnPrizeItemListener onPrizeItemListener = new PrizeAdapter.OnPrizeItemListener() {
        @Override
        public void onClick(int position) {
            if (mPrizeList != null && mPrizeList.size() > position && mPrizeList.get(position).getWinningId() != null) {
                Intent intent = new Intent(MyPrizeActivity.this, PrizeDetailActivity.class);
                intent.putExtra(IntentKey.KEY_PRIZE_ID, String.valueOf(mPrizeList.get(position).getWinningId()));
                startActivity(intent);
            }
        }
    };
}

package com.collalab.smartcheck.utils;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.text.TextUtils;

import com.google.zxing.common.StringUtils;

import java.io.File;
import java.lang.reflect.Field;
import java.util.Date;
import java.util.UUID;

/**
 * Created by laptop88 on 8/30/2017.
 */

public class CollaLabUtils {
    public static String isGUID(String src) {
        try {
            UUID.fromString(src);
            return src;
        } catch (Exception e) {
            return null;
        }
    }

    private Date apkUpdateTime(
            PackageManager packageManager, String packageName) {
        try {
            ApplicationInfo info = packageManager.getApplicationInfo(packageName, 0);
            File apkFile = new File(info.sourceDir);
            return apkFile.exists() ? new Date(apkFile.lastModified()) : null;
        } catch (PackageManager.NameNotFoundException e) {
            return null; // package not found
        }
    }

    private Date installTimeFromPackageManager(
            PackageManager packageManager, String packageName) {
        // API level 9 and above have the "firstInstallTime" field.
        // Check for it with reflection and return if present.
        try {
            PackageInfo info = packageManager.getPackageInfo(packageName, 0);
            Field field = PackageInfo.class.getField("firstInstallTime");
            long timestamp = field.getLong(info);
            return new Date(timestamp);
        } catch (PackageManager.NameNotFoundException e) {
            return null; // package not found
        } catch (IllegalAccessException e) {
        } catch (NoSuchFieldException e) {
        } catch (IllegalArgumentException e) {
        } catch (SecurityException e) {
        }
        return null;
    }

}

package com.collalab.smartcheck.networking;

import android.support.annotation.Nullable;

import retrofit2.Call;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * Created by VietMac on 2017-01-18.
 */

public interface ApiInterface {
    @POST("login")
    Call<String> login(@Query("phone") String phone, @Query("pass") String pass, @Query("key") String key);

    @POST("register")
    Call<String> registerAccount(@Query("name") String name, @Query("email") String email, @Query("phone") String phone, @Query("pass") String pass, @Query("user_id") String user_id, @Query("key") String key);

    @POST("check")
    Call<String> check(@Query("guid") String guid, @Query("user_id") String user_id, @Query("lon") double lng, @Query("lat") double lat, @Query("address") String address, @Query("key") String key, @Query("os") int os);
}
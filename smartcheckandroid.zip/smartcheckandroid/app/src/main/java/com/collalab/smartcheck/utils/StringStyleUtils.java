package com.collalab.smartcheck.utils;

import android.content.Context;
import android.graphics.Typeface;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.StyleSpan;

import com.collalab.smartcheck.R;
import com.collalab.smartcheck.model.Transfer;
import com.collalab.smartcheck.model.UserInfo;
import com.collalab.smartcheck.model.Voucher;

/**
 * Created by VietMac on 11/5/17.
 */

public class StringStyleUtils {
    public static SpannableStringBuilder getBoldElement(String src, int from, int to) {
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(src);
        spannableStringBuilder.setSpan(new StyleSpan(Typeface.BOLD), from, to, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        return spannableStringBuilder;
    }

    public static SpannableStringBuilder getBoldElements(String src, int from1, int to1, int from2, int to2) {
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(src);
        spannableStringBuilder.setSpan(new StyleSpan(Typeface.BOLD), from1, to1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableStringBuilder.setSpan(new StyleSpan(Typeface.BOLD), from2, to2, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        return spannableStringBuilder;
    }

    public static SpannableStringBuilder getTransferSuccessStr(Context context, UserInfo userInfo, Voucher voucher) {
        String customerName = !TextUtils.isEmpty(userInfo.getUserName()) ? userInfo.getUserName() : userInfo.getUserPhone();
        String customerPhone = userInfo.getUserPhone();
        String voucherName = voucher.getName();
        String customerTitle = context.getResources().getString(R.string.string_customer_name_title) + " ";
        String customerPhoneTitle = " " + context.getResources().getString(R.string.string_customer_phone_title) + " ";
        String customerVoucherTitle = " " + context.getResources().getString(R.string.string_customer_transfer_success);

        String content = customerTitle + customerName + customerPhoneTitle + customerPhone + customerVoucherTitle + voucherName;

        int startPhone = customerTitle.length() + customerName.length() + customerPhoneTitle.length();
        int endPhone = startPhone + customerPhone.length();

        int startVoucher = endPhone + customerVoucherTitle.length();
        int endVoucher = startVoucher + voucherName.length();

        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(content);
        spannableStringBuilder.setSpan(new StyleSpan(Typeface.BOLD), customerTitle.length(), customerTitle.length() + customerName.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableStringBuilder.setSpan(new StyleSpan(Typeface.BOLD), startPhone, endPhone, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableStringBuilder.setSpan(new StyleSpan(Typeface.BOLD), startVoucher, endVoucher, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        return spannableStringBuilder;
    }
}

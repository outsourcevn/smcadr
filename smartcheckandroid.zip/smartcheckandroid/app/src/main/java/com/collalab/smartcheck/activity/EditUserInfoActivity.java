package com.collalab.smartcheck.activity;

import android.content.Intent;
import android.content.res.Configuration;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.collalab.smartcheck.KeyGenerator;
import com.collalab.smartcheck.R;
import com.collalab.smartcheck.model.RequestResponse;
import com.collalab.smartcheck.model.UserInfo;
import com.collalab.smartcheck.networking.ApiClient;
import com.collalab.smartcheck.networking.ApiInterface;
import com.collalab.smartcheck.persistence.PreferenceUtils;
import com.collalab.smartcheck.persistence.PrefsKey;
import com.collalab.smartcheck.utils.DataParser;
import com.squareup.picasso.Picasso;

import java.net.SocketTimeoutException;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditUserInfoActivity extends BaseActivity {

    UserInfo mUserInfo;

    @BindView(R.id.tv_username)
    TextView mTvUserName;
    @BindView(R.id.tv_user_point)
    TextView mTvUserPoint;
    @BindView(R.id.edt_name)
    EditText mEdtName;
    @BindView(R.id.edt_phone)
    EditText mEdtPhone;
    @BindView(R.id.edt_email)
    EditText mEdtEmail;
    @BindView(R.id.edt_identify)
    EditText mEdtIdentify;
    @BindView(R.id.edt_address)
    EditText mEdtAddress;
    @BindView(R.id.edt_password)
    EditText mEdtPassword;
    @BindView(R.id.edt_confirm_password)
    EditText mEdtConfirmPassword;

    @BindView(R.id.imv_avatar)
    ImageView mImgUserAvatar;

    @BindView(R.id.btn_update)
    View mBtnUpdate;

    @BindView(R.id.scrollView)
    ScrollView mScrollView;

    boolean hasUpdated = false;

    ApiInterface apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_user_info);

        ButterKnife.bind(this);
        apiService = ApiClient.getClient().create(ApiInterface.class);
        PreferenceUtils.init(this);

        OverScrollDecoratorHelper.setUpOverScroll(mScrollView);

        getIntentData();

        bindUserInfo2Views();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        hasUpdated = false;

        getIntentData();

        bindUserInfo2Views();
    }

    private void getIntentData() {
        if (getIntent() != null && getIntent().getExtras() != null && getIntent().getExtras().containsKey(PrefsKey.KEY_USER_INFO)) {
            mUserInfo = (UserInfo) getIntent().getExtras().getSerializable(PrefsKey.KEY_USER_INFO);
        }
        getAndSetUserFacebookAvatar();
    }

    private void getAndSetUserFacebookAvatar() {
        String avatarUrl = PreferenceUtils.getString(PrefsKey.KEY_FACEBOOK_AVATAR_LINK, null);
        if (!TextUtils.isEmpty(avatarUrl)) {
            Picasso.with(this).load(avatarUrl).placeholder(R.drawable.ic_default_user).into(mImgUserAvatar);
        }
    }

    @OnClick(R.id.btn_back)
    public void onBackClick() {
        this.onBackPressed();
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent();
        intent.putExtra(PrefsKey.KEY_USER_INFO, mUserInfo);
        setResult(RESULT_OK, intent);
        finish();
    }

    @OnClick(R.id.btn_update)
    public void onUpdate() {
        mBtnUpdate.setEnabled(false);
        if (!TextUtils.isEmpty(mEdtConfirmPassword.getEditableText().toString()) || !TextUtils.isEmpty(mEdtPassword.getEditableText().toString())) {
            if (!mEdtPassword.getEditableText().toString().equals(mEdtConfirmPassword.getEditableText().toString())) {
                mEdtConfirmPassword.setError(getResources().getString(R.string.string_password_not_match));
                mBtnUpdate.setEnabled(true);
                return;
            } else {
                mEdtConfirmPassword.setError(null);
            }
        }

        if (TextUtils.isEmpty(mEdtPhone.getEditableText().toString())) {
            mEdtPhone.setError(getResources().getString(R.string.string_enter_phone));
            mBtnUpdate.setEnabled(true);
            return;
        } else {
            mEdtPhone.setError(null);
        }

        updateUserInfo_Network();

    }

    private void bindUserInfo2Views() {
        if (mUserInfo == null) {
            return;
        }

        if (!TextUtils.isEmpty(mUserInfo.getUserName())) {
            mTvUserName.setText(mUserInfo.getUserName());
            mEdtName.setText(mUserInfo.getUserName());
        } else if (!TextUtils.isEmpty(mUserInfo.getUserPhone())) {
            mTvUserName.setText(mUserInfo.getUserPhone());
        }

        if (!TextUtils.isEmpty(mUserInfo.getPoints())) {
            mTvUserPoint.setText(mUserInfo.getPoints());
        }

        if (!TextUtils.isEmpty(mUserInfo.getUserPhone())) {
            mEdtPhone.setText(mUserInfo.getUserPhone());
        }

        if (!TextUtils.isEmpty(mUserInfo.getUserEmail())) {
            mEdtEmail.setText(mUserInfo.getUserEmail());
        }

        if (!TextUtils.isEmpty(mUserInfo.getIdentify())) {
            mEdtIdentify.setText(mUserInfo.getIdentify());
        }

        if (!TextUtils.isEmpty(mUserInfo.getAddress())) {
            mEdtAddress.setText(mUserInfo.getAddress());
        }
    }

    private void reBindViewOnUpdateSuccess() {
        mTvUserName.setText(mEdtName.getEditableText().toString().trim());

        mUserInfo.setUserName(mEdtName.getEditableText().toString().trim());
        mUserInfo.setUserPhone(mEdtPhone.getEditableText().toString().trim());
        mUserInfo.setUserEmail(mEdtEmail.getEditableText().toString().trim());
        mUserInfo.setAddress(mEdtAddress.getEditableText().toString().trim());
        mUserInfo.setIdentify(mEdtIdentify.getEditableText().toString().trim());

    }

    private void updateUserInfo_Network() {
        buildProgressDialog();
        showLoadingProgress();
        mBtnUpdate.setEnabled(false);

        UserInfo userInfo = createUserInfoParameter();
        String password = mEdtPassword.getEditableText().toString();
        if (TextUtils.isEmpty(password)) {
            password = PreferenceUtils.getString(PrefsKey.KEY_USER_PASSWORD, null);
        }

        Call<String> call = apiService.updateAccount(userInfo.getUserName(), userInfo.getUserEmail(), userInfo.getUserPhone(), password,
                userInfo.getUserId(), userInfo.getIdentify(), userInfo.getAddress(), String.valueOf(KeyGenerator.generateKey()));
        call.enqueue(mUserInfoCallBack);
    }

    private UserInfo createUserInfoParameter() {
        UserInfo userInfo = new UserInfo();

        if (!TextUtils.isEmpty(mUserInfo.getUserId())) {
            userInfo.setUserId(mUserInfo.getUserId());
        }

        if (!TextUtils.isEmpty(mUserInfo.getPoints())) {
            userInfo.setPoints(mUserInfo.getPoints());
        }

        if (!TextUtils.isEmpty(mEdtName.getEditableText().toString().trim())) {
            userInfo.setUserName(mEdtName.getEditableText().toString().trim());
        } else {
            userInfo.setUserName(mUserInfo.getUserName());
        }

        if (!TextUtils.isEmpty(mEdtPhone.getEditableText().toString().trim())) {
            userInfo.setUserPhone(mEdtPhone.getEditableText().toString().trim());
        } else {
            userInfo.setUserPhone(mUserInfo.getUserPhone());
        }

        if (!TextUtils.isEmpty(mEdtEmail.getEditableText().toString().trim())) {
            userInfo.setUserEmail(mEdtEmail.getEditableText().toString().trim());
        } else {
            userInfo.setUserEmail(mUserInfo.getUserEmail());
        }

        if (!TextUtils.isEmpty(mEdtAddress.getEditableText().toString().trim())) {
            userInfo.setAddress(mEdtAddress.getEditableText().toString().trim());
        } else {
            userInfo.setAddress(mUserInfo.getAddress());
        }

        if (!TextUtils.isEmpty(mEdtIdentify.getEditableText().toString().trim())) {
            userInfo.setIdentify(mEdtIdentify.getEditableText().toString().trim());
        } else {
            userInfo.setIdentify(mUserInfo.getIdentify());
        }

        return userInfo;
    }

    Callback<String> mUserInfoCallBack = new Callback<String>() {
        @Override
        public void onResponse(Call<String> call, Response<String> response) {

            RequestResponse requestResponse = DataParser.getResponse(response.body());
            if (requestResponse.isSuccess()) {
                reBindViewOnUpdateSuccess();
                hasUpdated = true;
                if (!TextUtils.isEmpty(mEdtPassword.getEditableText().toString())) {
                    PreferenceUtils.commitString(PrefsKey.KEY_USER_PASSWORD, mEdtPassword.getEditableText().toString());
                }
                getUserInfo();
                Toast.makeText(EditUserInfoActivity.this, getResources().getString(R.string.string_update_account_success), Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(EditUserInfoActivity.this, requestResponse.getMessage(), Toast.LENGTH_SHORT).show();
            }

            hideLoadingProgress();
            mBtnUpdate.setEnabled(true);
        }

        @Override
        public void onFailure(Call<String> call, Throwable t) {
            if (t instanceof SocketTimeoutException) {
                showErrorMessage(getResources().getString(R.string.string_socket_timeout_exception));
            } else if (!isNetworkAvailable()) {
                showErrorMessage(getResources().getString(R.string.string_no_network_connection));
            } else {
                showErrorMessage(getResources().getString(R.string.string_cannot_update_user_info));
            }
            hideLoadingProgress();
            mBtnUpdate.setEnabled(true);
        }
    };

    private void getUserInfo() {

        buildProgressDialog();
        showLoadingProgress();

        Call<String> call = apiService.getUserInfo(mUserInfo.getUserId());
        call.enqueue(mUserCallBack);
    }

    Callback<String> mUserCallBack = new Callback<String>() {
        @Override
        public void onResponse(Call<String> call, Response<String> response) {
            RequestResponse requestResponse = DataParser.getResponse(response.body());
            if (requestResponse.isSuccess()) {
                mUserInfo = DataParser.getUserInfo(response.body());
                if (mUserInfo != null) {
                    PreferenceUtils.commitString(PrefsKey.KEY_USER_INFO, response.body());
                }
                bindUserInfo2Views();
            }
            hideLoadingProgress();
        }

        @Override
        public void onFailure(Call<String> call, Throwable t) {
            hideLoadingProgress();
        }
    };

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Checks whether a hardware keyboard is available
        if (newConfig.hardKeyboardHidden == Configuration.HARDKEYBOARDHIDDEN_NO) {
            Toast.makeText(this, "keyboard visible", Toast.LENGTH_SHORT).show();
        } else if (newConfig.hardKeyboardHidden == Configuration.HARDKEYBOARDHIDDEN_YES) {
            Toast.makeText(this, "keyboard hidden", Toast.LENGTH_SHORT).show();
        }
    }
}

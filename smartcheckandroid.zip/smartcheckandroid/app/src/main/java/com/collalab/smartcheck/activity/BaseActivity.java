package com.collalab.smartcheck.activity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.collalab.smartcheck.R;
import com.collalab.smartcheck.networking.ApiClient;
import com.collalab.smartcheck.networking.ApiInterface;
import com.collalab.smartcheck.widget.LoadingDialog;
import com.crashlytics.android.Crashlytics;

import io.nlopez.smartlocation.location.providers.LocationGooglePlayServicesProvider;
import retrofit2.Call;
import retrofit2.Callback;

/**
 * Created by VietMac on 11/4/17.
 */

public class BaseActivity extends RootActivity {
    Dialog mLoadingDialog;

    Dialog dialog;
    ImageView mIconMessage;
    TextView mTextViewMessage;

    protected ApiInterface apiService;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        apiService = ApiClient.getClient().create(ApiInterface.class);

        buildMessageDialog();
    }

    protected void doRewardPoint(String userId, String type, String point, Callback<String> callback) {
        Call<String> call = apiService.bonusPoints(userId, type, point);
        call.enqueue(callback);
    }

    private void buildMessageDialog() {
        if (dialog == null) {
            dialog = new Dialog(BaseActivity.this);

            dialog.getWindow()
                    .getAttributes().windowAnimations = R.style.DialogAnimation;

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.layout_message_dialog);

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(dialog.getWindow().getAttributes());
            lp.width = WindowManager.LayoutParams.MATCH_PARENT;
            dialog.getWindow().setAttributes(lp);

            mIconMessage = (ImageView) dialog.findViewById(R.id.ivIconMessage);
            mTextViewMessage = (TextView) dialog.findViewById(R.id.tvMessage);
        }
    }

    protected void showLoadingProgress() {
        if (mLoadingDialog != null && !mLoadingDialog.isShowing()) {
            mLoadingDialog.show();
        }
    }

    protected void hideLoadingProgress() {
        if (mLoadingDialog != null && mLoadingDialog.isShowing()) {
            mLoadingDialog.dismiss();
        }
    }

    protected void showMessageDialog() {
        if (dialog != null && !dialog.isShowing()) {
            dialog.show();
        }
    }

    public void showSuccessMessage(String content) {
        mIconMessage.setImageResource(R.drawable.ic_success_msg);
        mTextViewMessage.setText(content);
        showMessageDialog();
    }

    public void showErrorMessage(String content) {
        mIconMessage.setImageResource(R.drawable.error_icon);
        mTextViewMessage.setText(content);
        showMessageDialog();
    }

    protected void buildProgressDialog() {
        if (mLoadingDialog == null) {
            mLoadingDialog = LoadingDialog.createProgress(this);
        } else {
            mLoadingDialog.dismiss();
            mLoadingDialog = LoadingDialog.createProgress(this);
        }
        mLoadingDialog.setCanceledOnTouchOutside(false);
        mLoadingDialog.setOnKeyListener(keylistener);
    }

    DialogInterface.OnKeyListener keylistener = new DialogInterface.OnKeyListener() {
        public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
            if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
                return true;
            } else {
                return false;
            }
        }
    };

    protected void logUser(String userPhone, String userEmail) {
        Crashlytics.setUserIdentifier(userPhone);
        Crashlytics.setUserEmail(userEmail);
    }

}

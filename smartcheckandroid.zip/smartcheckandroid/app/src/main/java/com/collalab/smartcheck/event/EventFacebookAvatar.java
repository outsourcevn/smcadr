package com.collalab.smartcheck.event;

/**
 * Created by laptop88 on 11/8/2017.
 */

public class EventFacebookAvatar {
    public String avatarUrl;
}

package com.collalab.smartcheck.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.View;
import android.webkit.URLUtil;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.collalab.smartcheck.R;
import com.collalab.smartcheck.common.Constant;
import com.collalab.smartcheck.common.IntentKey;
import com.collalab.smartcheck.model.PrizeDetail;
import com.collalab.smartcheck.model.RequestResponse;
import com.collalab.smartcheck.networking.ApiClient;
import com.collalab.smartcheck.networking.ApiInterface;
import com.collalab.smartcheck.persistence.PreferenceUtils;
import com.collalab.smartcheck.utils.DataParser;
import com.collalab.smartcheck.utils.DateTimeUtils;
import com.collalab.smartcheck.utils.StringStyleUtils;
import com.crashlytics.android.answers.Answers;
import com.crashlytics.android.answers.ContentViewEvent;
import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;
import nl.dionsegijn.konfetti.KonfettiView;
import nl.dionsegijn.konfetti.models.Shape;
import nl.dionsegijn.konfetti.models.Size;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PrizeDetailActivity extends BaseActivity {

    @BindView(R.id.backdrop)
    ImageView mImgBackDrop;
    @BindView(R.id.webview)
    WebView mWebViewContent;
    @BindView(R.id.tv_name)
    TextView mTvNameVoucher;
    @BindView(R.id.tv_start_end_date)
    TextView mTvStartEndDate;

    @BindView(R.id.tv_prize_money)
    TextView mProductPrice;

    @BindView(R.id.image1)
    ImageView mImagePrize1;
    @BindView(R.id.image2)
    ImageView mImagePrize2;
    @BindView(R.id.image3)
    ImageView mImagePrize3;

    @BindView(R.id.layout_congratulation_text)
    View mLayoutCongratulationText;

    @BindView(R.id.scrollView)
    ScrollView mScrollView;

    ProgressDialog mProgressDialog;

    @BindView(R.id.konfettiView)
    KonfettiView mKonfettiView;

    ApiInterface apiService;
    String mPrizeId;
    PrizeDetail mPrizeDetail;
    NumberFormat mCurrencyFormatter;
    boolean shouldActiveKonfetti;

    ArrayList<String> mListVoucherImage = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitivity_prize_detail);

        mCurrencyFormatter = new DecimalFormat("#,###");

        ButterKnife.bind(this);
        apiService = ApiClient.getClient().create(ApiInterface.class);
        PreferenceUtils.init(this);

        OverScrollDecoratorHelper.setUpOverScroll(mScrollView);
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setMessage("Loading...");

        getIntentData();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                getDetailVoucher();
            }
        }, 200);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        getIntentData();
        getDetailVoucher();
    }

    private void getIntentData() {

        shouldActiveKonfetti = false;

        if (getIntent() != null && getIntent().getExtras() != null && getIntent().getExtras().containsKey(IntentKey.KEY_PRIZE_ID)) {
            mPrizeId = getIntent().getExtras().getString(IntentKey.KEY_PRIZE_ID);
        } else if (getIntent() != null && getIntent().getExtras() != null && getIntent().getExtras().containsKey(IntentKey.INTENT_KEY_SHOW_CONGRATULATION)) {
            shouldActiveKonfetti = true;
            mPrizeId = getIntent().getExtras().getString(IntentKey.INTENT_KEY_SHOW_CONGRATULATION);
        }
    }

    private void activeKonfettiView() {
        mKonfettiView.build()
                .addColors(ContextCompat.getColor(this, R.color.lt_yellow), ContextCompat.getColor(this, R.color.lt_orange), ContextCompat.getColor(this, R.color.lt_purple), ContextCompat.getColor(this, R.color.lt_pink))
                .setDirection(0.0, 359.0)
                .setSpeed(1f, 5f)
                .setFadeOutEnabled(true)
                .setTimeToLive(2000L)
                .addShapes(Shape.RECT, Shape.CIRCLE)
                .addSizes(new Size(12, 5f))
                .setPosition(mKonfettiView.getX() + mKonfettiView.getWidth() / 2, mKonfettiView.getY() + mKonfettiView.getHeight() / 4)
                .stream(300, 2500L);
    }

    private void bindVoucherDetail2Views() {

        if (shouldActiveKonfetti) {
            mLayoutCongratulationText.setVisibility(View.VISIBLE);
        } else {
            mLayoutCongratulationText.setVisibility(View.GONE);
        }

        mWebViewContent.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
        });

        if (mPrizeDetail == null)
            return;
        if (URLUtil.isValidUrl(Constant.HOST_NAME + mPrizeDetail.getBigImage())) {
            Picasso.with(this).load(Constant.HOST_NAME + mPrizeDetail.getBigImage()).placeholder(R.drawable.bg_top_bar).error(R.drawable.bg_top_bar).into(mImgBackDrop);
        }

        if (!TextUtils.isEmpty(mPrizeDetail.getName())) {
            mTvNameVoucher.setText(mPrizeDetail.getName());
        }

        if (!TextUtils.isEmpty(mPrizeDetail.getDes())) {
            mWebViewContent.loadData(mPrizeDetail.getDes(), "text/html; charset=UTF-8", null);
        }

        if (!TextUtils.isEmpty(mPrizeDetail.getFromDate()) && !TextUtils.isEmpty(mPrizeDetail.getToDate())) {

            String startEndDateStr = String.format(getResources().getString(R.string.string_start_end_date_prize), DateTimeUtils.getPrizeDate(mPrizeDetail.getFromDate()), DateTimeUtils.getPrizeDate(mPrizeDetail.getToDate()));
            int start1 = startEndDateStr.indexOf(DateTimeUtils.getPrizeDate(mPrizeDetail.getFromDate()));
            int end1 = start1 + DateTimeUtils.getVoucherDateStr(mPrizeDetail.getFromDate()).length();

            int start2 = startEndDateStr.lastIndexOf(DateTimeUtils.getPrizeDate(mPrizeDetail.getToDate()));
            int end2 = start2 + DateTimeUtils.getVoucherDateStr(mPrizeDetail.getToDate()).length();

            mTvStartEndDate.setText(StringStyleUtils.getBoldElements(startEndDateStr, start1, end1, start2, end2));
            mTvStartEndDate.setVisibility(View.VISIBLE);
        }

        if (!TextUtils.isEmpty(mPrizeDetail.getMoney()) && TextUtils.isDigitsOnly(mPrizeDetail.getMoney())) {
            String formattedPrice = mCurrencyFormatter.format(Double.valueOf(mPrizeDetail.getMoney()));
            mProductPrice.setText(String.format(getString(R.string.string_wining_price), formattedPrice));
        }

        if (shouldActiveKonfetti) {
            activeKonfettiView();
        }

    }

    @OnClick(R.id.btn_back)
    public void onBackClick() {
        finish();
    }

    @OnClick(R.id.backdrop)
    public void onBackDropClick() {
        Intent intent = new Intent(this, ImageViewPagerActivity.class);
        intent.putExtra(IntentKey.INTENT_KEY_IMG_INDEX, 0);
        intent.putStringArrayListExtra(IntentKey.INTENT_KEY_LIST_IMG, mListVoucherImage);
        startActivity(intent);
    }

    @OnClick(R.id.image1)
    public void onImage1Click() {
        Intent intent = new Intent(this, ImageViewPagerActivity.class);
        intent.putExtra(IntentKey.INTENT_KEY_IMG_INDEX, 1);
        intent.putStringArrayListExtra(IntentKey.INTENT_KEY_LIST_IMG, mListVoucherImage);
        startActivity(intent);
    }

    @OnClick(R.id.image2)
    public void onImage2Click() {
        Intent intent = new Intent(this, ImageViewPagerActivity.class);
        intent.putExtra(IntentKey.INTENT_KEY_IMG_INDEX, 2);
        intent.putStringArrayListExtra(IntentKey.INTENT_KEY_LIST_IMG, mListVoucherImage);
        startActivity(intent);
    }

    @OnClick(R.id.image3)
    public void onImage3Click() {
        Intent intent = new Intent(this, ImageViewPagerActivity.class);
        intent.putExtra(IntentKey.INTENT_KEY_IMG_INDEX, 3);
        intent.putStringArrayListExtra(IntentKey.INTENT_KEY_LIST_IMG, mListVoucherImage);
        startActivity(intent);
    }

    private void showProgressDialog() {
        if (mProgressDialog != null && !mProgressDialog.isShowing()) {
            mProgressDialog.show();
        }
    }

    private void hideProgressDialog() {
        if (mProgressDialog != null) {
            mProgressDialog.dismiss();
        }
    }

    private void getDetailVoucher() {

        showProgressDialog();

        Call<String> call = apiService.getWinningDetail(mPrizeId);
        call.enqueue(mPrizeDetailCallBack);
    }

    Callback<String> mPrizeDetailCallBack = new Callback<String>() {
        @Override
        public void onResponse(Call<String> call, Response<String> response) {
            RequestResponse requestResponse = DataParser.getResponse(response.body());
            if (requestResponse.isSuccess()) {
                mPrizeDetail = DataParser.parsePrizeDetail(response.body());

                logViewVoucherDetail();

                initVoucherImageList();

                bindVoucherDetail2Views();
            } else {
                Toast.makeText(PrizeDetailActivity.this, requestResponse.getMessage(), Toast.LENGTH_SHORT).show();
            }
            hideProgressDialog();
        }

        @Override
        public void onFailure(Call<String> call, Throwable t) {
            hideProgressDialog();
        }
    };

    private void initVoucherImageList() {
        mListVoucherImage.clear();
        if (!TextUtils.isEmpty(mPrizeDetail.getBigImage())) {
            mListVoucherImage.add(mPrizeDetail.getBigImage());
        }
        if (!TextUtils.isEmpty(mPrizeDetail.getImage1())) {
            mListVoucherImage.add(mPrizeDetail.getImage1());
        }

        if (!TextUtils.isEmpty(mPrizeDetail.getImage2())) {
            mListVoucherImage.add(mPrizeDetail.getImage2());
        }

        if (!TextUtils.isEmpty(mPrizeDetail.getImage3())) {
            mListVoucherImage.add(mPrizeDetail.getImage3());
        }

        if (mListVoucherImage.size() <= 1) {
            mImagePrize1.setVisibility(View.GONE);
            mImagePrize2.setVisibility(View.GONE);
            mImagePrize3.setVisibility(View.GONE);
        } else if (mListVoucherImage.size() == 2) {
            mImagePrize1.setVisibility(View.VISIBLE);
            Picasso.with(this).load(Constant.HOST_NAME + mListVoucherImage.get(1)).placeholder(R.drawable.no_image_holder).into(mImagePrize1);

            mImagePrize2.setVisibility(View.GONE);
            mImagePrize3.setVisibility(View.GONE);
        } else if (mListVoucherImage.size() == 3) {
            mImagePrize1.setVisibility(View.VISIBLE);
            Picasso.with(this).load(Constant.HOST_NAME + mListVoucherImage.get(1)).placeholder(R.drawable.no_image_holder).into(mImagePrize1);

            mImagePrize2.setVisibility(View.VISIBLE);
            Picasso.with(this).load(Constant.HOST_NAME + mListVoucherImage.get(2)).placeholder(R.drawable.no_image_holder).into(mImagePrize2);

            mImagePrize3.setVisibility(View.GONE);
        } else if (mListVoucherImage.size() == 4) {
            mImagePrize1.setVisibility(View.VISIBLE);
            Picasso.with(this).load(Constant.HOST_NAME + mListVoucherImage.get(1)).placeholder(R.drawable.no_image_holder).into(mImagePrize1);
            mImagePrize2.setVisibility(View.VISIBLE);
            Picasso.with(this).load(Constant.HOST_NAME + mListVoucherImage.get(2)).placeholder(R.drawable.no_image_holder).into(mImagePrize2);
            mImagePrize3.setVisibility(View.VISIBLE);
            Picasso.with(this).load(Constant.HOST_NAME + mListVoucherImage.get(3)).placeholder(R.drawable.no_image_holder).into(mImagePrize3);
        }

    }

    private void logViewVoucherDetail() {
        if (mPrizeDetail != null) {
            Answers.getInstance().logContentView(new ContentViewEvent()
                    .putContentName(mPrizeDetail.getName())
                    .putContentType("View Prize")
                    .putContentId("Prize-" + mPrizeId));
        }
    }
}
package com.collalab.smartcheck.model;

/**
 * Created by VietMac on 11/5/17.
 */

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Scan {

    @SerializedName("info")
    @Expose
    private String info;
    @SerializedName("active")
    @Expose
    private String active;
    @SerializedName("point")
    @Expose
    private String point;
    @SerializedName("total")
    @Expose
    private String total;
    @SerializedName("winning_id")
    @Expose
    private String winningId;

    /**
     * No args constructor for use in serialization
     */
    public Scan() {
    }

    /**
     * @param total
     * @param point
     * @param winningId
     * @param active
     * @param info
     */
    public Scan(String info, String active, String point, String total, String winningId) {
        super();
        this.info = info;
        this.active = active;
        this.point = point;
        this.total = total;
        this.winningId = winningId;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getPoint() {
        return point;
    }

    public void setPoint(String point) {
        this.point = point;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getWinningId() {
        return winningId;
    }

    public void setWinningId(String winningId) {
        this.winningId = winningId;
    }

}

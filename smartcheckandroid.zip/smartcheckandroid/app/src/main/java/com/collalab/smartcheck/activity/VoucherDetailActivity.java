package com.collalab.smartcheck.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.URLUtil;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.collalab.smartcheck.KeyGenerator;
import com.collalab.smartcheck.R;
import com.collalab.smartcheck.common.Constant;
import com.collalab.smartcheck.common.IntentKey;
import com.collalab.smartcheck.dialog.TransferSuccessDialog;
import com.collalab.smartcheck.event.EventChangePoint;
import com.collalab.smartcheck.model.RequestResponse;
import com.collalab.smartcheck.model.Transfer;
import com.collalab.smartcheck.model.TransferVoucher;
import com.collalab.smartcheck.model.UserInfo;
import com.collalab.smartcheck.model.Voucher;
import com.collalab.smartcheck.model.VoucherDetail;
import com.collalab.smartcheck.networking.ApiClient;
import com.collalab.smartcheck.networking.ApiInterface;
import com.collalab.smartcheck.persistence.PreferenceUtils;
import com.collalab.smartcheck.persistence.PrefsKey;
import com.collalab.smartcheck.utils.DataParser;
import com.collalab.smartcheck.utils.DateTimeUtils;
import com.collalab.smartcheck.utils.StringStyleUtils;
import com.crashlytics.android.answers.Answers;
import com.crashlytics.android.answers.ContentViewEvent;
import com.squareup.picasso.Picasso;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class VoucherDetailActivity extends BaseActivity {

    @BindView(R.id.backdrop)
    ImageView mImgBackDrop;
    @BindView(R.id.webview)
    WebView mWebViewContent;
    @BindView(R.id.tv_name)
    TextView mTvNameVoucher;
    @BindView(R.id.tv_start_end_date)
    TextView mTvStartEndDate;

    @BindView(R.id.tv_point)
    TextView mTvPointToBuy;
    @BindView(R.id.tv_slot)
    TextView mTvRemainSlot;

    @BindView(R.id.image1)
    ImageView mImageVoucher1;
    @BindView(R.id.image2)
    ImageView mImageVoucher2;
    @BindView(R.id.image3)
    ImageView mImageVoucher3;

    @BindView(R.id.btn_update)
    TextView mTvUseOrBuyVoucher;

    @BindView(R.id.scrollView)
    ScrollView mScrollView;

    ProgressDialog mProgressDialog;

    ApiInterface apiService;
    String mVoucherId;
    VoucherDetail mVoucherDetail;
    UserInfo mUserInfo;

    TransferVoucher mTransferVoucher;

    ArrayList<String> mListVoucherImage = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voucher_detail);

        ButterKnife.bind(this);
        apiService = ApiClient.getClient().create(ApiInterface.class);
        PreferenceUtils.init(this);

        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setMessage("Loading...");

        OverScrollDecoratorHelper.setUpOverScroll(mScrollView);

        mUserInfo = DataParser.getUserInfo(PreferenceUtils.getString(PrefsKey.KEY_USER_INFO, null));

        getIntentData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                getDetailVoucher();
            }
        }, 200);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        getIntentData();
        getDetailVoucher();
    }

    private void getIntentData() {
        if (getIntent() != null && getIntent().getExtras() != null && getIntent().getExtras().containsKey(IntentKey.KEY_VOUCHER_ID)) {
            mVoucherId = getIntent().getExtras().getString(IntentKey.KEY_VOUCHER_ID);
        }

        if (getIntent() != null && getIntent().getExtras() != null && getIntent().getExtras().containsKey(IntentKey.KEY_TRANSFER_VOUCHER)) {
            mTransferVoucher = (TransferVoucher) getIntent().getExtras().getSerializable(IntentKey.KEY_TRANSFER_VOUCHER);
        }
    }

    private void bindVoucherDetail2Views() {

        if (mTransferVoucher != null) {
            mTvUseOrBuyVoucher.setBackgroundResource(R.drawable.bg_use_voucher);
            mTvUseOrBuyVoucher.setTextColor(Color.WHITE);
            mTvUseOrBuyVoucher.setText(R.string.string_use_voucher);

            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 0, 0);
            mTvUseOrBuyVoucher.setLayoutParams(lp);
        }

        mTvUseOrBuyVoucher.setVisibility(View.VISIBLE);

        mWebViewContent.getSettings().setJavaScriptEnabled(false);

        if (mVoucherDetail == null)
            return;
        if (URLUtil.isValidUrl(Constant.HOST_NAME + mVoucherDetail.getBigImage())) {
            Picasso.with(this).load(Constant.HOST_NAME + mVoucherDetail.getBigImage()).placeholder(R.drawable.bg_top_bar).error(R.drawable.bg_top_bar).into(mImgBackDrop);
        }

        if (!TextUtils.isEmpty(mVoucherDetail.getName())) {
            mTvNameVoucher.setText(mVoucherDetail.getName());
            mTvNameVoucher.setVisibility(View.VISIBLE);
        }

        if (!TextUtils.isEmpty(mVoucherDetail.getFullDes())) {
            mWebViewContent.loadDataWithBaseURL("", mVoucherDetail.getFullDes(), "text/html", "UTF-8", "");
        }

        if (!TextUtils.isEmpty(mVoucherDetail.getFromDate()) && !TextUtils.isEmpty(mVoucherDetail.getToDate())) {
            String startEndDateStr = String.format(getResources().getString(R.string.string_start_end_date), DateTimeUtils.getVoucherDateStr(mVoucherDetail.getFromDate()), DateTimeUtils.getVoucherDateStr(mVoucherDetail.getToDate()));
            int start1 = startEndDateStr.indexOf(DateTimeUtils.getVoucherDateStr(mVoucherDetail.getFromDate()));
            int end1 = start1 + DateTimeUtils.getVoucherDateStr(mVoucherDetail.getFromDate()).length();

            int start2 = startEndDateStr.lastIndexOf(DateTimeUtils.getVoucherDateStr(mVoucherDetail.getToDate()));
            int end2 = start2 + DateTimeUtils.getVoucherDateStr(mVoucherDetail.getToDate()).length();

            mTvStartEndDate.setText(StringStyleUtils.getBoldElements(startEndDateStr, start1, end1, start2, end2));
            mTvStartEndDate.setVisibility(View.VISIBLE);
        }

        String numPoint = mVoucherDetail.getPoint() != null ? mVoucherDetail.getPoint() : "0";
        String numSlot = mVoucherDetail.getQuantity() != null ? mVoucherDetail.getQuantity() : "0";

        String strPointToBuy = String.format(getResources().getString(R.string.string_point_to_buy), numPoint);
        String strRemainSlot = String.format(getResources().getString(R.string.string_remain_slot), numSlot);

        mTvPointToBuy.setText(StringStyleUtils.getBoldElement(strPointToBuy, strPointToBuy.indexOf(numPoint), strPointToBuy.indexOf(numPoint) + numPoint.length()));
        mTvRemainSlot.setText(StringStyleUtils.getBoldElement(strRemainSlot, strRemainSlot.indexOf(numSlot), strRemainSlot.indexOf(numSlot) + numSlot.length()));

        mTvPointToBuy.setVisibility(View.VISIBLE);
        mTvRemainSlot.setVisibility(View.VISIBLE);
    }

    @OnClick(R.id.btn_back)
    public void onBackClick() {
        finish();
    }

    @OnClick(R.id.backdrop)
    public void onBackDropClick() {
        Intent intent = new Intent(this, ImageViewPagerActivity.class);
        intent.putExtra(IntentKey.INTENT_KEY_IMG_INDEX, 0);
        intent.putStringArrayListExtra(IntentKey.INTENT_KEY_LIST_IMG, mListVoucherImage);
        startActivity(intent);
    }

    @OnClick(R.id.image1)
    public void onImage1Click() {
        Intent intent = new Intent(this, ImageViewPagerActivity.class);
        intent.putExtra(IntentKey.INTENT_KEY_IMG_INDEX, 1);
        intent.putStringArrayListExtra(IntentKey.INTENT_KEY_LIST_IMG, mListVoucherImage);
        startActivity(intent);
    }

    @OnClick(R.id.image2)
    public void onImage2Click() {
        Intent intent = new Intent(this, ImageViewPagerActivity.class);
        intent.putExtra(IntentKey.INTENT_KEY_IMG_INDEX, 2);
        intent.putStringArrayListExtra(IntentKey.INTENT_KEY_LIST_IMG, mListVoucherImage);
        startActivity(intent);
    }

    @OnClick(R.id.image3)
    public void onImage3Click() {
        Intent intent = new Intent(this, ImageViewPagerActivity.class);
        intent.putExtra(IntentKey.INTENT_KEY_IMG_INDEX, 3);
        intent.putStringArrayListExtra(IntentKey.INTENT_KEY_LIST_IMG, mListVoucherImage);
        startActivity(intent);
    }

    @OnClick(R.id.btn_update)
    public void onBuyVoucher() {
        if (mTransferVoucher == null) {
            getUserInfoAndBuy();
        } else {
            showVoucherCode();
        }
    }

    private void showVoucherCode() {
        Intent intent = new Intent(this, UseVoucherActivity.class);
        intent.putExtra(IntentKey.KEY_TRANSFER_VOUCHER, mTransferVoucher);
        intent.putExtra(IntentKey.KEY_VOUCHER_DETAIL, mVoucherDetail);
        startActivity(intent);
    }

    private void showProgressDialog() {
        if (mProgressDialog != null && !mProgressDialog.isShowing()) {
            mProgressDialog.show();
        }
    }

    private void hideProgressDialog() {
        if (mProgressDialog != null) {
            mProgressDialog.dismiss();
        }
    }

    private void getDetailVoucher() {

        showProgressDialog();

        Call<String> call = apiService.getVoucherDetail(mVoucherId);
        call.enqueue(mVoucherDetailCallBack);
    }

    Callback<String> mVoucherDetailCallBack = new Callback<String>() {
        @Override
        public void onResponse(Call<String> call, Response<String> response) {
            RequestResponse requestResponse = DataParser.getResponse(response.body());
            if (requestResponse.isSuccess()) {
                mVoucherDetail = DataParser.parseVoucherDetail(response.body());

                logViewVoucherDetail();

                initVoucherImageList();

                bindVoucherDetail2Views();
            } else {
                Toast.makeText(VoucherDetailActivity.this, requestResponse.getMessage(), Toast.LENGTH_SHORT).show();
            }
            hideProgressDialog();
        }

        @Override
        public void onFailure(Call<String> call, Throwable t) {
            hideProgressDialog();
        }
    };

    private void initVoucherImageList() {
        mListVoucherImage.clear();
        if (!TextUtils.isEmpty(mVoucherDetail.getBigImage())) {
            mListVoucherImage.add(mVoucherDetail.getBigImage());
        }
        if (!TextUtils.isEmpty(mVoucherDetail.getImage1())) {
            mListVoucherImage.add(mVoucherDetail.getImage1());
        }

        if (!TextUtils.isEmpty(mVoucherDetail.getImage2())) {
            mListVoucherImage.add(mVoucherDetail.getImage2());
        }

        if (!TextUtils.isEmpty(mVoucherDetail.getImage3())) {
            mListVoucherImage.add(mVoucherDetail.getImage3());
        }

        if (mListVoucherImage.size() <= 1) {
            mImageVoucher1.setVisibility(View.GONE);
            mImageVoucher2.setVisibility(View.GONE);
            mImageVoucher3.setVisibility(View.GONE);
        } else if (mListVoucherImage.size() == 2) {
            mImageVoucher1.setVisibility(View.VISIBLE);
            Picasso.with(this).load(Constant.HOST_NAME + mListVoucherImage.get(1)).placeholder(R.drawable.no_image_holder).into(mImageVoucher1);

            mImageVoucher2.setVisibility(View.GONE);
            mImageVoucher3.setVisibility(View.GONE);
        } else if (mListVoucherImage.size() == 3) {
            mImageVoucher1.setVisibility(View.VISIBLE);
            Picasso.with(this).load(Constant.HOST_NAME + mListVoucherImage.get(1)).placeholder(R.drawable.no_image_holder).into(mImageVoucher1);

            mImageVoucher2.setVisibility(View.VISIBLE);
            Picasso.with(this).load(Constant.HOST_NAME + mListVoucherImage.get(2)).placeholder(R.drawable.no_image_holder).into(mImageVoucher2);

            mImageVoucher3.setVisibility(View.GONE);
        } else if (mListVoucherImage.size() == 4) {
            mImageVoucher1.setVisibility(View.VISIBLE);
            Picasso.with(this).load(Constant.HOST_NAME + mListVoucherImage.get(1)).placeholder(R.drawable.no_image_holder).into(mImageVoucher1);
            mImageVoucher2.setVisibility(View.VISIBLE);
            Picasso.with(this).load(Constant.HOST_NAME + mListVoucherImage.get(2)).placeholder(R.drawable.no_image_holder).into(mImageVoucher2);
            mImageVoucher3.setVisibility(View.VISIBLE);
            Picasso.with(this).load(Constant.HOST_NAME + mListVoucherImage.get(3)).placeholder(R.drawable.no_image_holder).into(mImageVoucher3);
        }

    }

    private void checkPointToBuy() {
        if (!TextUtils.isEmpty(mVoucherDetail.getPoint()) && TextUtils.isDigitsOnly(mVoucherDetail.getPoint()) && mUserInfo != null &&
                Integer.valueOf(mVoucherDetail.getPoint()) <= Integer.valueOf(mUserInfo.getPoints())) {
            doBuyVoucher();
        } else {
            showErrorMessage(getResources().getString(R.string.string_error_enough_point_to_buy));
        }
    }

    private void doBuyVoucher() {

        if (mUserInfo == null || mVoucherId == null || mVoucherDetail == null) {
            return;
        }

        final String address = PreferenceUtils.getString(PrefsKey.KEY_LOCATION, "");
        String lat = PreferenceUtils.getString(PrefsKey.KEY_LATITUDE, null);
        String lng = PreferenceUtils.getString(PrefsKey.KEY_LONGITUDE, null);
        String pointsBuy = mVoucherDetail.getPoint();

        Call<String> call = apiService.transferVoucher(mUserInfo.getUserId(), mVoucherId, pointsBuy, lng, lat, address, String.valueOf(KeyGenerator.generateKey()));
        call.enqueue(mBuyRewardCallBack);
    }

    private void getUserInfoAndBuy() {

        if (mUserInfo == null)
            return;

        buildProgressDialog();
        showProgressDialog();

        Call<String> call = apiService.getUserInfo(mUserInfo.getUserId());
        call.enqueue(mUserInfoCallBack);
    }

    Callback<String> mUserInfoCallBack = new Callback<String>() {
        @Override
        public void onResponse(Call<String> call, Response<String> response) {
            RequestResponse requestResponse = DataParser.getResponse(response.body());
            if (requestResponse.isSuccess()) {
                mUserInfo = DataParser.getUserInfo(response.body());
                if (mUserInfo != null) {
                    PreferenceUtils.commitString(PrefsKey.KEY_USER_INFO, response.body());
                }
            }
            checkPointToBuy();
            hideProgressDialog();
        }

        @Override
        public void onFailure(Call<String> call, Throwable t) {
            checkPointToBuy();
            hideProgressDialog();
        }
    };

    Callback<String> mBuyRewardCallBack = new Callback<String>() {
        @Override
        public void onResponse(Call<String> call, Response<String> response) {
            RequestResponse requestResponse = DataParser.getResponse(response.body());
            if (requestResponse != null && requestResponse.isSuccess()) {
                Transfer transfer = DataParser.parseTransferVoucher(response.body());
                if (transfer != null) {
                    if (mTransferVoucher == null) {
                        mTransferVoucher = new TransferVoucher();
                        mTransferVoucher.setVoucherName(mVoucherDetail.getName());
                        mTransferVoucher.setCode(transfer.getCode());
                        bindVoucherDetail2Views();
                    }

                    Voucher voucher = new Voucher();
                    voucher.setName(mVoucherDetail.getName());

                    TransferSuccessDialog transferSuccessDialog = new TransferSuccessDialog(VoucherDetailActivity.this, voucher, transfer, mUserInfo);
                    transferSuccessDialog.show();

                    EventChangePoint eventChangePoint = new EventChangePoint();
                    eventChangePoint.newPoint = transfer.getTotal();
                    EventBus.getDefault().post(eventChangePoint);
                }
            }
            hideProgressDialog();
        }

        @Override
        public void onFailure(Call<String> call, Throwable t) {
            hideProgressDialog();
        }
    };

    private void logViewVoucherDetail() {
        if (mVoucherDetail != null) {
            if (mTransferVoucher != null) {
                Answers.getInstance().logContentView(new ContentViewEvent()
                        .putContentName(mVoucherDetail.getName())
                        .putContentType("Buyed Voucher")
                        .putContentId("Voucher-" + mVoucherId));
            } else {
                Answers.getInstance().logContentView(new ContentViewEvent()
                        .putContentName(mVoucherDetail.getName())
                        .putContentType("Not Buyed Voucher")
                        .putContentId("Voucher-" + mVoucherId));
            }
        }
    }
}
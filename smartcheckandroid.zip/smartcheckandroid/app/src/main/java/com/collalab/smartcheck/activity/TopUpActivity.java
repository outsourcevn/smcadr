package com.collalab.smartcheck.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.collalab.smartcheck.R;

import butterknife.ButterKnife;
import butterknife.OnClick;

public class TopUpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_top_up);
        ButterKnife.bind(this);
    }

    @OnClick(R.id.btn_back)
    public void onBackClick() {
        finish();
    }
}

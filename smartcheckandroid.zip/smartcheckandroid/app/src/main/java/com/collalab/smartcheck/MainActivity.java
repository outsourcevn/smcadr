package com.collalab.smartcheck;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Location;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomSheetBehavior;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.URLUtil;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.collalab.smartcheck.networking.ApiClient;
import com.collalab.smartcheck.networking.ApiInterface;
import com.collalab.smartcheck.persistence.PreferenceUtils;
import com.collalab.smartcheck.persistence.PrefsKey;
import com.collalab.smartcheck.utils.CollaLabUtils;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.location.Geofence;
import com.google.zxing.Result;

import org.json.JSONObject;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import io.nlopez.smartlocation.OnActivityUpdatedListener;
import io.nlopez.smartlocation.OnGeofencingTransitionListener;
import io.nlopez.smartlocation.OnLocationUpdatedListener;
import io.nlopez.smartlocation.OnReverseGeocodingListener;
import io.nlopez.smartlocation.SmartLocation;
import io.nlopez.smartlocation.geofencing.model.GeofenceModel;
import io.nlopez.smartlocation.geofencing.utils.TransitionGeofence;
import io.nlopez.smartlocation.location.providers.LocationGooglePlayServicesProvider;
import me.dm7.barcodescanner.zxing.ZXingScannerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends AppCompatActivity implements ZXingScannerView.ResultHandler, OnLocationUpdatedListener, OnActivityUpdatedListener, OnGeofencingTransitionListener {

    private static final int LOCATION_PERMISSION_ID = 1001;
    private static final int PERMISSIONS_REQUEST_CAMERA = 1002;
    private static final int MY_PERMISSIONS_REQUEST_CAMERA = 1003;
    FragmentTransaction fragmentTransaction;
    FragmentManager fragmentManager;
    ScanCodeFragment scanCodeFragment;

    @Bind(R.id.scanner_view)
    ZXingScannerView mScannerView;

    @Bind(R.id.warranty_info)
    TextView mWarrantyInfo;
    @Bind(R.id.point_info)
    TextView mPointInfo;
    @Bind(R.id.address_info)
    TextView mAddressInfo;

    TextView mScannedCode;

    View layoutRequestInfo;
    View scanCodeGuide;
    FrameLayout scanCodeContainer;

    ProgressDialog mProgressDialog;

    private BottomSheetBehavior mBottomSheetBehavior;

    double lat, lng;
    String address = "";
    private LocationGooglePlayServicesProvider provider;

    ApiInterface apiService;

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().requestFeature(Window.FEATURE_ACTION_BAR);
        getSupportActionBar().hide();

        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        mProgressDialog = new ProgressDialog(MainActivity.this);
        mProgressDialog.setTitle("Đang gửi");
        mProgressDialog.setMessage("Vui lòng đợi phản hồi trong giây lát...");

        apiService = ApiClient.getClient().create(ApiInterface.class);

        mScannedCode = (TextView) findViewById(R.id.scanned_code);
        layoutRequestInfo = findViewById(R.id.layout_request_info);
        scanCodeGuide = findViewById(R.id.scan_code_guide);

        findViewById(R.id.btn_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(R.id.btn_more).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SettingActivity.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.btn_scan).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mScannerView != null) {
                    mScannerView.resumeCameraPreview(MainActivity.this);
                }
                scanCodeGuide.setVisibility(View.VISIBLE);
                layoutRequestInfo.setVisibility(View.GONE);
            }
        });

        PreferenceUtils.init(this);

        if (PreferenceUtils.getBoolean(PrefsKey.KEY_IS_LOGGED_IN, false)) {
            mScannerView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mScannerView.startCamera();
                }
            });
        } else {
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
        }
    }

    public boolean checkPermissionAndRequest() {
        int permissionCAMERA = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
        int permissionLOCATION = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);

        List<String> listPermissionsNeeded = new ArrayList<>();
        if (permissionLOCATION != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (permissionCAMERA != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.CAMERA);
        }
        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), MY_PERMISSIONS_REQUEST_CAMERA);
            return true;
        }
        return false;
    }

    public void getCameraPermission() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(MainActivity.this,
                    Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                        Manifest.permission.CAMERA)) {

                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.CAMERA},
                            PERMISSIONS_REQUEST_CAMERA);

                } else {
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.CAMERA},
                            PERMISSIONS_REQUEST_CAMERA);
                }
            }
        }

    }

    @Override
    public void onResume() {
        super.onResume();

        if (!checkPermissionAndRequest()) {
            startLocation();
        }

        if (mScannerView != null) {
            mScannerView.setResultHandler(this);
            mScannerView.startCamera();
            mScannerView.resumeCameraPreview(MainActivity.this);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (mScannerView != null) {
            mScannerView.stopCamera();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        SmartLocation.with(this).activityRecognition().stop();
        SmartLocation.with(this).location(provider).stop();
    }

    private void getLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_ID);
            return;
        }
        startLocation();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {

            case MY_PERMISSIONS_REQUEST_CAMERA:
                if (grantResults.length == 2) {

                    boolean locationPermission = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean cameraPermission = grantResults[1] == PackageManager.PERMISSION_GRANTED;

                    if (locationPermission) {
                        startLocation();
                    }
                    if (cameraPermission) {
                        mScannerView.resumeCameraPreview(MainActivity.this);
                    }
                } else if (grantResults.length == 1) {
                    if (Manifest.permission.ACCESS_FINE_LOCATION.equalsIgnoreCase(permissions[0])) {
                        startLocation();
                    } else {
                        mScannerView.resumeCameraPreview(MainActivity.this);
                    }
                }

                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (provider != null) {
            provider.onActivityResult(requestCode, resultCode, data);
        }

    }

    private void startLocation() {

        provider = new LocationGooglePlayServicesProvider();
        provider.setCheckLocationSettings(true);

        SmartLocation smartLocation = new SmartLocation.Builder(this).logging(true).build();

        smartLocation.location(provider).start(this);
        smartLocation.activity().start(this);

        GeofenceModel mestalla = new GeofenceModel.Builder("1").setTransition(Geofence.GEOFENCE_TRANSITION_ENTER).setLatitude(39.47453120000001).setLongitude(-0.358065799999963).setRadius(500).build();
        smartLocation.geofencing().add(mestalla).start(this);
    }

    @Override
    public void handleResult(Result result) {
        MediaPlayer mediaPlayer = MediaPlayer.create(this, R.raw.raw_tick);
        mediaPlayer.start();
        handleScanCode(result.getText());
    }

    public void handleScanCode(final String src) {
        if (TextUtils.isEmpty(src)) {
            displayMessage("Không tìm thấy mã theo yêu cầu!");
        } else {
            if (URLUtil.isValidUrl(src)) {
                Intent intent = new Intent(MainActivity.this, WebViewActivity.class);
                intent.putExtra("url", src);
                startActivity(intent);
            } else if (!TextUtils.isEmpty(CollaLabUtils.checkAndGetUUID(src))) {
                if(!mProgressDialog.isShowing()) {
                    mProgressDialog.show();
                }
                Call<String> call = apiService.check(CollaLabUtils.checkAndGetUUID(src), PreferenceUtils.getString(PrefsKey.KEY_USER_ID, ""), lng, lat, address, String.valueOf(KeyGenerator.generateKey()), 1);
                call.enqueue(new Callback<String>() {
                    @Override
                    public void onResponse(Call<String> call, Response<String> response) {
                        Log.i("SmartCheck", response.body().toString());
                        if (!TextUtils.isEmpty(response.body().toString())) {
                            Bundle bundle = new Bundle();
                            bundle.putString("data", response.body().toString());
                            bundle.putString("scanned_code", src);
                            bundle.putString("address", address);
                            Fragment fragment = getSupportFragmentManager().findFragmentByTag("Info_Bottom_Sheet_Dialog");
                            if (fragment != null) {
                                getSupportFragmentManager().beginTransaction().remove(fragment);
                            }
                            CustomBottomSheetDialog bottomSheetDialog = CustomBottomSheetDialog.getInstance();
                            bottomSheetDialog.setArguments(bundle);
                            bottomSheetDialog.show(getSupportFragmentManager(), "Info_Bottom_Sheet_Dialog");
                            bottomSheetDialog.setOnBottomSheetClose(new CustomBottomSheetDialog.OnBottomSheetClose() {
                                @Override
                                public void onClose() {
                                    if (mScannerView != null) {
                                        mScannerView.resumeCameraPreview(MainActivity.this);
                                    }
                                }
                            });
                        } else {
                            displayMessage(getResources().getString(R.string.string_scan_code_eror_server));
                            scanCodeGuide.setVisibility(View.VISIBLE);
                            layoutRequestInfo.setVisibility(View.GONE);
                        }
                        mProgressDialog.dismiss();
                    }

                    @Override
                    public void onFailure(Call<String> call, Throwable t) {
                        if (isNetworkAvailable()) {
                            displayMessage(getResources().getString(R.string.string_scan_code_eror_server));
                        } else {
                            displayMessage(getResources().getString(R.string.string_no_network_send_code));
                        }
                        scanCodeGuide.setVisibility(View.VISIBLE);
                        layoutRequestInfo.setVisibility(View.GONE);
                        mProgressDialog.dismiss();
                    }
                });

            } else {
                displayMessage(getResources().getString(R.string.string_scan_code_not_smart_check));
            }
        }

    }

    public void displayMessage(String message) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("Close", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        if (mScannerView != null) {
                            mScannerView.resumeCameraPreview(MainActivity.this);
                        }
                        dialog.dismiss();
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        alertDialog.show();
    }

    @Override
    public void onActivityUpdated(DetectedActivity detectedActivity) {

    }

    @Override
    public void onGeofenceTransition(TransitionGeofence transitionGeofence) {

    }

    @Override
    public void onLocationUpdated(Location location) {
        showLocation(location);
    }

    private void showLocation(Location location) {
        if (location != null) {

            lat = location.getLatitude();
            lng = location.getLongitude();

            SmartLocation.with(this).geocoding().reverse(location, new OnReverseGeocodingListener() {
                @Override
                public void onAddressResolved(Location original, List<Address> results) {
                    if (results.size() > 0) {
                        Address result = results.get(0);
                        StringBuilder builder = new StringBuilder();
                        List<String> addressElements = new ArrayList<>();
                        for (int i = 0; i <= result.getMaxAddressLineIndex(); i++) {
                            addressElements.add(result.getAddressLine(i));
                        }
                        builder.append(TextUtils.join(", ", addressElements));
                        address = builder.toString();
                        PreferenceUtils.commitString(PrefsKey.KEY_LOCATION, builder.toString());
                        PreferenceUtils.commitString(PrefsKey.KEY_LATITUDE, String.valueOf(lat));
                        PreferenceUtils.commitString(PrefsKey.KEY_LONGITUDE, String.valueOf(lng));
                    }
                }
            });
        } else {

        }
    }

    public boolean isNetworkAvailable() {
        ConnectivityManager connectivityMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityMgr.getActiveNetworkInfo();
        /// if no network is available networkInfo will be null
        if (networkInfo != null && networkInfo.isConnected()) {
            return true;
        }
        return false;
    }
}

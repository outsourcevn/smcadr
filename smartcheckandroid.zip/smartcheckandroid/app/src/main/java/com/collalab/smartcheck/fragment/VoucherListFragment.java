package com.collalab.smartcheck.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.collalab.smartcheck.KeyGenerator;
import com.collalab.smartcheck.R;
import com.collalab.smartcheck.activity.TabActivity;
import com.collalab.smartcheck.activity.VoucherDetailActivity;
import com.collalab.smartcheck.adapter.VoucherAdapter;
import com.collalab.smartcheck.common.IntentKey;
import com.collalab.smartcheck.dialog.TransferSuccessDialog;
import com.collalab.smartcheck.event.EventChangePoint;
import com.collalab.smartcheck.listener.OnChangePointListener;
import com.collalab.smartcheck.model.RequestResponse;
import com.collalab.smartcheck.model.Transfer;
import com.collalab.smartcheck.model.UserInfo;
import com.collalab.smartcheck.model.Voucher;
import com.collalab.smartcheck.networking.ApiClient;
import com.collalab.smartcheck.networking.ApiInterface;
import com.collalab.smartcheck.persistence.PreferenceUtils;
import com.collalab.smartcheck.persistence.PrefsKey;
import com.collalab.smartcheck.utils.DataParser;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class VoucherListFragment extends BaseFragment {

    ArrayList<Voucher> mListVoucher;
    ApiInterface apiService;

    @BindView(R.id.recycler_view)
    RecyclerView mRecyclerView;
    @BindView(R.id.progress_bar)
    ProgressBar mProgressBar;
    @BindView(R.id.siwpe_layout)
    SwipeRefreshLayout mSwipeRefreshLayout;

    VoucherAdapter mVoucherAdapter;
    private GridLayoutManager mGridLayoutManager;

    private boolean isOnResumed;
    UserInfo mUserInfo;
    String mUserId;
    int mWantBuyItemIndex = -1;

    OnChangePointListener mOnChangePointListener;

    public VoucherListFragment() {

    }

    public void setOnChangePointListener(OnChangePointListener onChangePointListener) {
        this.mOnChangePointListener = onChangePointListener;
    }

    public static VoucherListFragment newInstance() {
        VoucherListFragment fragment = new VoucherListFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        apiService = ApiClient.getClient().create(ApiInterface.class);
        mUserId = PreferenceUtils.getString(PrefsKey.KEY_USER_ID, null);
        mUserInfo = DataParser.getUserInfo(PreferenceUtils.getString(PrefsKey.KEY_USER_INFO, null));

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_voucher_list, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mGridLayoutManager = new GridLayoutManager(getContext(), 2);
        mVoucherAdapter = new VoucherAdapter(getContext(), mListVoucher);
        mVoucherAdapter.setOnVoucherItemListener(mOnVoucherItemListener);
        mRecyclerView.setAdapter(mVoucherAdapter);
        mRecyclerView.setLayoutManager(mGridLayoutManager);
        mRecyclerView.setHasFixedSize(true);

        setUpSwipeToRefreshLayout();

        getVoucherList_Network();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!isOnResumed) {
            isOnResumed = true;
            if (getUserVisibleHint()) {
                getVoucherList_Network();
            }
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        if (isVisibleToUser && isOnResumed) {
            getVoucherList_Network();
        }
    }

    private void getVoucherList_Network() {

        if (!mSwipeRefreshLayout.isRefreshing()) {
            mProgressBar.setVisibility(View.VISIBLE);
        }

        Call<String> call = apiService.getVoucherList();
        call.enqueue(mListVoucherCallBack);
    }

    Callback<String> mListVoucherCallBack = new Callback<String>() {
        @Override
        public void onResponse(Call<String> call, Response<String> response) {
            RequestResponse requestResponse = DataParser.getResponse(response.body());
            if (requestResponse.isSuccess()) {
                mListVoucher = DataParser.parseVoucherList(response.body());
                bindVoucherListViews();
            } else {
                Toast.makeText(getContext(), requestResponse.getMessage(), Toast.LENGTH_SHORT).show();
            }
            hideLoadingIndicator();
        }

        @Override
        public void onFailure(Call<String> call, Throwable t) {
            hideLoadingIndicator();
        }
    };

    private void hideLoadingIndicator() {
        if (mSwipeRefreshLayout.isRefreshing()) {
            mSwipeRefreshLayout.setRefreshing(false);
        } else {
            mProgressBar.setVisibility(View.GONE);
        }
    }

    VoucherAdapter.OnVoucherItemListener mOnVoucherItemListener = new VoucherAdapter.OnVoucherItemListener() {
        @Override
        public void onClick(int position) {
            Intent intent = new Intent(getContext(), VoucherDetailActivity.class);
            intent.putExtra(IntentKey.KEY_VOUCHER_ID, String.valueOf(mListVoucher.get(position).getId()));
            startActivity(intent);
        }

        @Override
        public void onBuy(int position) {
            mWantBuyItemIndex = position;
            getUserInfo();
        }
    };

    private void bindVoucherListViews() {
        if (mListVoucher != null && mListVoucher.size() > 0) {
            mVoucherAdapter.setVoucherList(mListVoucher);
        }
    }

    private void setUpSwipeToRefreshLayout() {
        mSwipeRefreshLayout.setColorSchemeColors(ContextCompat.getColor(getContext(), R.color.color_actionbar));
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getVoucherList_Network();
            }
        });
    }

    private void checkPointToBuy() {
        if (mUserInfo != null && mWantBuyItemIndex != -1 && mListVoucher.get(mWantBuyItemIndex).getPoint() <= Integer.valueOf(mUserInfo.getPoints())) {
            doBuyVoucher(mWantBuyItemIndex);
        } else {
            showErrorMessage(getResources().getString(R.string.string_error_enough_point_to_buy));
        }
    }

    private void doBuyVoucher(int wantedBuyIndex) {

        if (mUserId == null || wantedBuyIndex == -1) {
            return;
        }

        if (!mSwipeRefreshLayout.isRefreshing()) {
            mProgressBar.setVisibility(View.VISIBLE);
        }

        final String address = PreferenceUtils.getString(PrefsKey.KEY_LOCATION, "");
        String lat = PreferenceUtils.getString(PrefsKey.KEY_LATITUDE, "0");
        String lng = PreferenceUtils.getString(PrefsKey.KEY_LONGITUDE, "0");
        String voucherId = mListVoucher.get(wantedBuyIndex).getId() != null ? String.valueOf(mListVoucher.get(wantedBuyIndex).getId()) : null;
        String pointsBuy = mListVoucher.get(wantedBuyIndex).getPoint() != null ? String.valueOf(mListVoucher.get(wantedBuyIndex).getPoint()) : null;

        Call<String> call = apiService.transferVoucher(mUserId, voucherId, pointsBuy, lng, lat, address, String.valueOf(KeyGenerator.generateKey()));
        call.enqueue(mBuyRewardCallBack);
    }

    private void getUserInfo() {

        if (!mSwipeRefreshLayout.isRefreshing()) {
            mProgressBar.setVisibility(View.VISIBLE);
        }

        Call<String> call = apiService.getUserInfo(mUserId);
        call.enqueue(mUserInfoCallBack);
    }

    Callback<String> mUserInfoCallBack = new Callback<String>() {
        @Override
        public void onResponse(Call<String> call, Response<String> response) {
            RequestResponse requestResponse = DataParser.getResponse(response.body());
            if (requestResponse.isSuccess()) {
                mUserInfo = DataParser.getUserInfo(response.body());
                if (mUserInfo != null) {
                    PreferenceUtils.commitString(PrefsKey.KEY_USER_INFO, response.body());
                }
            }
            checkPointToBuy();
            hideLoadingIndicator();
        }

        @Override
        public void onFailure(Call<String> call, Throwable t) {
            checkPointToBuy();
            hideLoadingIndicator();
        }
    };

    Callback<String> mBuyRewardCallBack = new Callback<String>() {
        @Override
        public void onResponse(Call<String> call, Response<String> response) {
            RequestResponse requestResponse = DataParser.getResponse(response.body());
            if (requestResponse != null && requestResponse.isSuccess()) {
                Transfer transfer = DataParser.parseTransferVoucher(response.body());
                if (mOnChangePointListener != null) {
                    mOnChangePointListener.onChangePoint(transfer.getTotal());
                }

                if (transfer != null) {
                    TransferSuccessDialog transferSuccessDialog = new TransferSuccessDialog(getContext(), mListVoucher.get(mWantBuyItemIndex), transfer, mUserInfo);
                    transferSuccessDialog.show();

                    EventChangePoint eventChangePoint = new EventChangePoint();
                    eventChangePoint.newPoint = transfer.getTotal();
                    EventBus.getDefault().post(eventChangePoint);

                }
            }
            mWantBuyItemIndex = -1;
            hideLoadingIndicator();
        }

        @Override
        public void onFailure(Call<String> call, Throwable t) {
            mWantBuyItemIndex = -1;
            hideLoadingIndicator();
        }
    };

}

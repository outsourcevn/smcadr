package com.collalab.smartcheck.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.collalab.smartcheck.R;
import com.collalab.smartcheck.model.ProductScan;
import com.collalab.smartcheck.utils.DateTimeUtils;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ProductScanAdapter extends RecyclerView.Adapter<ProductScanAdapter.VoucherViewHolder> {

    private List<ProductScan> mProductScanList;
    private Context mContext;

    public void setOnProductScanItemListener(OnProductScanItemListener onProductScanItemListener) {
        this.onProductScanItemListener = onProductScanItemListener;
    }

    OnProductScanItemListener onProductScanItemListener;

    public interface OnProductScanItemListener {
        void onClick(int position);
    }

    public class VoucherViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.tv_guid_scanned)
        TextView textGuidScanned;
        @BindView(R.id.tv_address)
        TextView textAddress;
        @BindView(R.id.tv_point_per_scan)
        TextView textPointPerScan;
        @BindView(R.id.tv_product_company)
        TextView textCompany;
        @BindView(R.id.tv_date)
        TextView textScanDate;

        public VoucherViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }
    }

    public ProductScanAdapter(Context context, List<ProductScan> productScan) {
        this.mContext = context;
        this.mProductScanList = productScan;
    }

    @Override
    public VoucherViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_scan_history_item, parent, false);

        return new VoucherViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(VoucherViewHolder holder, final int position) {

        ProductScan productScan = mProductScanList.get(position);

        if (!TextUtils.isEmpty(productScan.getGuid())) {
            holder.textGuidScanned.setText(productScan.getGuid());
        }

        if (!TextUtils.isEmpty(productScan.getAddress())) {
            holder.textAddress.setText(String.format(mContext.getResources().getString(R.string.string_scan_at_address), productScan.getAddress()));
        } else if (!TextUtils.isEmpty(productScan.getProvince())) {
            holder.textAddress.setText(String.format(mContext.getResources().getString(R.string.string_scan_at_address), productScan.getProvince()));
        } else {
            holder.textAddress.setText(mContext.getResources().getString(R.string.string_unknown));
        }

        if (productScan.getPoints() != null) {
            holder.textPointPerScan.setText(String.format(mContext.getString(R.string.string_point_per_scan), String.valueOf(productScan.getPoints())));
        }

        if (!TextUtils.isEmpty(productScan.getDateTime())) {
            holder.textScanDate.setText(String.format(mContext.getString(R.string.string_scan_at_time), DateTimeUtils.getScannedDateFormattedStr(productScan.getDateTime())));
        } else {
            holder.textScanDate.setText(mContext.getResources().getString(R.string.string_unknown));
        }

        if (!TextUtils.isEmpty(productScan.getCompany())) {
            holder.textCompany.setText(String.format(mContext.getString(R.string.string_product_of), productScan.getCompany()));
        } else {
            holder.textCompany.setText(mContext.getResources().getString(R.string.string_unknown));
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onProductScanItemListener != null) {
                    onProductScanItemListener.onClick(position);
                }
            }
        });

    }

    public void setProductScanList(List<ProductScan> productScanList) {
        this.mProductScanList = productScanList;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return mProductScanList == null ? 0 : mProductScanList.size();
    }
}
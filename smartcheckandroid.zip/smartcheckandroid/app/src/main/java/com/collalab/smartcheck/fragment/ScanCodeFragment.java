package com.collalab.smartcheck.fragment;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.URLUtil;
import android.widget.TextView;

import com.collalab.smartcheck.CustomBottomSheetDialog;
import com.collalab.smartcheck.EventScan;
import com.collalab.smartcheck.KeyGenerator;
import com.collalab.smartcheck.R;
import com.collalab.smartcheck.activity.MainActivity;
import com.collalab.smartcheck.activity.PrizeDetailActivity;
import com.collalab.smartcheck.activity.WebViewActivity;
import com.collalab.smartcheck.common.Constant;
import com.collalab.smartcheck.common.IntentKey;
import com.collalab.smartcheck.listener.OnChangePointListener;
import com.collalab.smartcheck.model.PointConfig;
import com.collalab.smartcheck.model.PrizeDetail;
import com.collalab.smartcheck.model.RequestResponse;
import com.collalab.smartcheck.model.Scan;
import com.collalab.smartcheck.networking.ApiClient;
import com.collalab.smartcheck.networking.ApiInterface;
import com.collalab.smartcheck.persistence.PreferenceUtils;
import com.collalab.smartcheck.persistence.PrefsKey;
import com.collalab.smartcheck.utils.CollaLabUtils;
import com.collalab.smartcheck.utils.DataParser;
import com.google.zxing.Result;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import me.dm7.barcodescanner.zxing.ZXingScannerView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ScanCodeFragment extends BaseFragment implements ZXingScannerView.ResultHandler {

    protected static final int MY_PERMISSIONS_REQUEST_CAMERA = 1003;

    @BindView(R.id.scanner_view)
    ZXingScannerView mScannerView;

    @BindView(R.id.warranty_info)
    TextView mWarrantyInfo;
    @BindView(R.id.point_info)
    TextView mPointInfo;
    @BindView(R.id.address_info)
    TextView mAddressInfo;

    TextView mScannedCode;

    View layoutRequestInfo;
    View scanCodeGuide;

    @BindView(R.id.layout_camera_error)
    View mLayoutCameraError;
    @BindView(R.id.tv_camera_error)
    TextView mTvCameraError;

    ProgressDialog mProgressDialog;

    OnChangePointListener mOnChangePointListener;

    public ScanCodeFragment() {

    }

    public static ScanCodeFragment newInstance(boolean quetLienTuc) {
        ScanCodeFragment fragment = new ScanCodeFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mProgressDialog = new ProgressDialog(getContext());
        mProgressDialog.setTitle("Đang gửi");
        mProgressDialog.setMessage("Vui lòng đợi phản hồi trong giây lát...");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_scan_code, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mScannedCode = (TextView) view.findViewById(R.id.scanned_code);
        layoutRequestInfo = view.findViewById(R.id.layout_request_info);
        scanCodeGuide = view.findViewById(R.id.scan_code_guide);

        view.findViewById(R.id.btn_scan).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mScannerView != null) {
                    mScannerView.resumeCameraPreview(ScanCodeFragment.this);
                }
                scanCodeGuide.setVisibility(View.VISIBLE);
                layoutRequestInfo.setVisibility(View.GONE);
            }
        });

        mScannerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startCameraToScan();
            }
        });

    }

    private void startCameraToScan() {
        if (!checkPermissionAndRequest()) {
            if (mScannerView != null) {
                mScannerView.setResultHandler(this);
                mScannerView.startCamera();
                mScannerView.resumeCameraPreview(ScanCodeFragment.this);
            }
        }
    }

    public boolean checkPermissionAndRequest() {
        int permissionCAMERA = ContextCompat.checkSelfPermission(getContext(), Manifest.permission.CAMERA);

        List<String> listPermissionsNeeded = new ArrayList<>();
        if (permissionCAMERA != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.CAMERA);
        }
        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(getActivity(), listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), MY_PERMISSIONS_REQUEST_CAMERA);
            return true;
        }
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {

            case MY_PERMISSIONS_REQUEST_CAMERA:
                if (grantResults.length == 1) {
                    boolean cameraPermission = grantResults[0] == PackageManager.PERMISSION_GRANTED;

                    if (cameraPermission) {
                        startCameraToScan();
                    }
                }

                break;
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mProgressDialog != null) {
            mProgressDialog.cancel();
        }
        if (mScannerView != null) {
            mScannerView.stopCameraPreview();
        }
    }

    @Override
    public void handleResult(Result result) {
        MediaPlayer mediaPlayer = MediaPlayer.create(getContext(), R.raw.raw_tick);
        mediaPlayer.start();
        handleScanCode(result.getText());
    }

    @Override
    public void onResume() {
        super.onResume();

        verifyCameraBeforeScan();

    }

    private void verifyCameraBeforeScan() {
        PackageManager packageManager = getContext().getPackageManager();
        if (packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA)) {
            startCameraToScan();
        } else {
            mTvCameraError.setText(getResources().getString(R.string.string_no_camera));
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        mScannerView.stopCamera();
    }

    public void handleScanCode(final String src) {

        final String address = PreferenceUtils.getString(PrefsKey.KEY_LOCATION, "");
        Double lat = Double.valueOf(PreferenceUtils.getString(PrefsKey.KEY_LATITUDE, "0"));
        Double lng = Double.valueOf(PreferenceUtils.getString(PrefsKey.KEY_LONGITUDE, "0"));

        PointConfig pointConfig = DataParser.parsePointConfig(PreferenceUtils.getString(PrefsKey.KEY_POINT_CONFIG, null));
        String scanAddPoint = pointConfig != null ? pointConfig.getCheckPoint() : "0";

        if (TextUtils.isEmpty(src)) {
            displayMessage("Không tìm thấy mã theo yêu cầu!");
        } else {
            if (URLUtil.isValidUrl(src)) {
                Intent intent = new Intent(getContext(), WebViewActivity.class);
                intent.putExtra("url", src);
                startActivity(intent);
            } else if (!TextUtils.isEmpty(CollaLabUtils.isGUID(src))) {
                if (!mProgressDialog.isShowing()) {
                    mProgressDialog.show();
                }
                Call<String> call = apiService.check(src, PreferenceUtils.getString(PrefsKey.KEY_USER_ID, ""), lng, lat, address, String.valueOf(KeyGenerator.generateKey()), scanAddPoint, Constant.I_AM_ANDROID);
                call.enqueue(new Callback<String>() {
                    @Override
                    public void onResponse(Call<String> call, Response<String> response) {
                        Log.i("SmartCheck", response.body().toString());

                        RequestResponse requestResponse = DataParser.getResponse(response.body());

                        if (response.isSuccessful()) {
                            if (!TextUtils.isEmpty(response.body().toString())) {

                                Bundle bundle = new Bundle();
                                bundle.putString("data", response.body().toString());
                                bundle.putString("scanned_code", src);
                                bundle.putString("address", address);
                                Fragment fragment = getChildFragmentManager().findFragmentByTag("Info_Bottom_Sheet_Dialog");
                                if (fragment != null) {
                                    getChildFragmentManager().beginTransaction().remove(fragment);
                                }
                                CustomBottomSheetDialog bottomSheetDialog = CustomBottomSheetDialog.getInstance();
                                bottomSheetDialog.setArguments(bundle);
                                bottomSheetDialog.show(getChildFragmentManager(), "Info_Bottom_Sheet_Dialog");
                                bottomSheetDialog.setOnBottomSheetClose(new CustomBottomSheetDialog.OnBottomSheetClose() {
                                    @Override
                                    public void onClose() {
                                        startCameraToScan();
                                    }
                                });

                                if (requestResponse != null && requestResponse.isSuccess()) {
                                    Scan scan = DataParser.parseOneScan(response.body());
                                    if (!TextUtils.isEmpty(scan.getTotal())) {
                                        if (mOnChangePointListener != null) {
                                            mOnChangePointListener.onChangePoint(scan.getTotal());
                                        }
                                    }
                                    if (!TextUtils.isEmpty(scan.getWinningId())) {
                                        Intent intent = new Intent(getContext(), PrizeDetailActivity.class);
                                        intent.putExtra(IntentKey.INTENT_KEY_SHOW_CONGRATULATION, scan.getWinningId());
                                        startActivity(intent);
                                    }
                                }

                            } else {
                                displayMessage(getResources().getString(R.string.string_scan_code_eror_server));
                                scanCodeGuide.setVisibility(View.VISIBLE);
                                layoutRequestInfo.setVisibility(View.GONE);
                            }
                        } else {
                            displayMessage(getResources().getString(R.string.string_scan_code_eror_server));
                        }
                        mProgressDialog.dismiss();
                    }

                    @Override
                    public void onFailure(Call<String> call, Throwable t) {
                        if (isConnected()) {
                            displayMessage(getResources().getString(R.string.string_scan_code_eror_server));
                        } else {
                            displayMessage(getResources().getString(R.string.string_no_network_send_code));
                        }
                        scanCodeGuide.setVisibility(View.VISIBLE);
                        layoutRequestInfo.setVisibility(View.GONE);
                        mProgressDialog.dismiss();
                    }
                });

            } else {
                displayMessageNotSC(getResources().getString(R.string.string_scan_code_not_smart_check));
            }
        }

    }

    public void displayMessage(String message) {
        android.support.v7.app.AlertDialog.Builder alertDialogBuilder = new android.support.v7.app.AlertDialog.Builder(getContext());
        alertDialogBuilder
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("Close", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        if (mScannerView != null) {
                            startCameraToScan();
                        }
                        dialog.dismiss();
                    }
                });

        android.support.v7.app.AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        alertDialog.show();
    }

    public void displayMessageNotSC(String message) {
        android.support.v7.app.AlertDialog.Builder alertDialogBuilder = new android.support.v7.app.AlertDialog.Builder(getContext());
        alertDialogBuilder
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("Close", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        Intent intent = new Intent(getContext(), WebViewActivity.class);
                        intent.putExtra("url", "http://smartcheck.vn/");
                        startActivity(intent);

                        if (mScannerView != null) {
                            startCameraToScan();
                        }

                        dialog.dismiss();
                    }
                });

        android.support.v7.app.AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        alertDialog.show();
    }

    public void setOnChangePointListener(OnChangePointListener onChangePointListener) {
        this.mOnChangePointListener = onChangePointListener;
    }
}

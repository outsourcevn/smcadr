package com.collalab.smartcheck.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.collalab.smartcheck.R;
import com.collalab.smartcheck.common.Constant;
import com.collalab.smartcheck.common.IntentKey;
import com.collalab.smartcheck.model.TransferVoucher;
import com.collalab.smartcheck.model.VoucherDetail;
import com.collalab.smartcheck.persistence.PreferenceUtils;
import com.squareup.picasso.Picasso;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class UseVoucherActivity extends BaseActivity {

    @BindView(R.id.tv_title)
    TextView mTvTitle;
    @BindView(R.id.tv_voucher_code)
    TextView mTvVoucherCode;
    @BindView(R.id.img_voucher)
    ImageView mImgVoucher;

    TransferVoucher mTransferVoucher;
    VoucherDetail mVoucherDetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_use_voucher);
        ButterKnife.bind(this);
        PreferenceUtils.init(this);
        getIntentData();
        bindData2Views();
    }

    @OnClick(R.id.btn_back)
    public void onBackClick() {
        finish();
    }

    private void getIntentData() {
        if (getIntent() != null && getIntent().getExtras() != null && getIntent().getExtras().containsKey(IntentKey.KEY_TRANSFER_VOUCHER)) {
            mTransferVoucher = (TransferVoucher) getIntent().getExtras().getSerializable(IntentKey.KEY_TRANSFER_VOUCHER);
        }

        if (getIntent() != null && getIntent().getExtras() != null && getIntent().getExtras().containsKey(IntentKey.KEY_VOUCHER_DETAIL)) {
            mVoucherDetail = (VoucherDetail) getIntent().getExtras().getSerializable(IntentKey.KEY_VOUCHER_DETAIL);
        }
    }

    private void bindData2Views() {

        if (mTransferVoucher != null && mVoucherDetail != null) {
            mTvTitle.setText(mTransferVoucher.getVoucherName());
            mTvVoucherCode.setText(mTransferVoucher.getCode());
            Picasso.with(this).load(Constant.HOST_NAME + mVoucherDetail.getImage()).placeholder(R.drawable.no_image_holder).into(mImgVoucher);
        }
    }

}

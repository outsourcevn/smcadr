package com.collalab.smartcheck.utils;

import android.text.TextUtils;

import com.google.zxing.common.StringUtils;

import java.util.UUID;

/**
 * Created by laptop88 on 8/30/2017.
 */

public class CollaLabUtils {
    public static String isGUID(String src) {
        try {
            UUID.fromString(src);
            return src;
        } catch (Exception e) {
            return null;
        }
    }
}

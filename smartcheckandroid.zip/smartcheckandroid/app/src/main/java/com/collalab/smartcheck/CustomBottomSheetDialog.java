package com.collalab.smartcheck;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetDialogFragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

/**
 * Created by laptop88 on 8/31/2017.
 */

public class CustomBottomSheetDialog extends BottomSheetDialogFragment {

    String dataJson;
    String scannedCode;
    String address;
    View layoutProductInfo, layoutWarrantyInfo, layoutPointInfo, layoutAddressInfo;
    TextView tvProductInfo, tvWarrantyInfo, tvPointInfo, tvAddressInfo;

    public static CustomBottomSheetDialog getInstance() {
        return new CustomBottomSheetDialog();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        if (getArguments() != null && getArguments().containsKey("data")) {
            dataJson = getArguments().getString("data");
        }
        if (getArguments() != null && getArguments().containsKey("scanned_code")) {
            scannedCode = getArguments().getString("scanned_code");
        }
        if (getArguments() != null && getArguments().containsKey("address")) {
            address = getArguments().getString("address");
        }

        return inflater.inflate(R.layout.layout_custom_bottom_sheet, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {

        layoutProductInfo = view.findViewById(R.id.layout_product_info);
        layoutWarrantyInfo = view.findViewById(R.id.layout_warranty_info);
        layoutPointInfo = view.findViewById(R.id.layout_point_info);
        layoutAddressInfo = view.findViewById(R.id.layout_address_info);

        tvProductInfo = (TextView) view.findViewById(R.id.tv_info_content);
        tvWarrantyInfo = (TextView) view.findViewById(R.id.tv_warranty_content);
        tvPointInfo = (TextView) view.findViewById(R.id.tv_point_content);
        tvAddressInfo = (TextView) view.findViewById(R.id.tv_location_content);
        String cutStr = scannedCode.replaceAll("\n$", "");
        while (cutStr.endsWith("\n")) {
            cutStr = cutStr.substring(0, cutStr.length() - 2);
        }
        tvProductInfo.setText("" + cutStr);
        layoutProductInfo.setVisibility(View.VISIBLE);

        if (!TextUtils.isEmpty(dataJson)) {
            try {
                JSONObject jsonObject = new JSONObject(dataJson);
                if (jsonObject.has("status") && "success".equalsIgnoreCase(jsonObject.getString("status"))) {
                    if (jsonObject.has("data") && jsonObject.getJSONArray("data").length() > 0) {
                        if (((JSONObject) jsonObject.getJSONArray("data").get(0)).has("active")) {
                            String warranty = ((JSONObject) jsonObject.getJSONArray("data").get(0)).getString("active");
                            if (TextUtils.isEmpty(warranty)) {
                                layoutWarrantyInfo.setVisibility(View.GONE);
                            } else {
                                layoutWarrantyInfo.setVisibility(View.VISIBLE);
                                tvWarrantyInfo.setText("" + warranty);
                            }
                        }

                        if (((JSONObject) jsonObject.getJSONArray("data").get(0)).has("active")) {
                            String point = ((JSONObject) jsonObject.getJSONArray("data").get(0)).getString("point");
                            if (TextUtils.isEmpty(point)) {
                                layoutPointInfo.setVisibility(View.GONE);
                            } else {
                                layoutPointInfo.setVisibility(View.VISIBLE);
                                tvPointInfo.setText("" + point);
                            }
                        }
                        if (!TextUtils.isEmpty(address)) {
                            layoutAddressInfo.setVisibility(View.VISIBLE);
                            tvAddressInfo.setText("" + address);
                        } else {
                            layoutAddressInfo.setVisibility(View.GONE);
                        }
                    }
                } else if (jsonObject.has("status") && "failed".equalsIgnoreCase(jsonObject.getString("status"))) {

                }
                if (jsonObject.has("message")) {
                    Toast.makeText(CustomBottomSheetDialog.this.getContext(), String.valueOf(jsonObject.getString("message")), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(CustomBottomSheetDialog.this.getContext(), getResources().getString(R.string.string_scan_code_eror_server), Toast.LENGTH_SHORT).show();
            }
        } else {
            dismiss();
        }
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);
        if(mOnBottomSheetClose != null) {
            mOnBottomSheetClose.onClose();
        }
    }

    private OnBottomSheetClose mOnBottomSheetClose;

    public void setOnBottomSheetClose(OnBottomSheetClose onBottomSheetClose) {
        this.mOnBottomSheetClose = onBottomSheetClose;
    }

    public interface OnBottomSheetClose{
        void onClose();
    }

}
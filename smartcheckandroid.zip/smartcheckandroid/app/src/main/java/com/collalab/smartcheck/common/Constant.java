package com.collalab.smartcheck.common;

/**
 * Created by VietMac on 11/4/17.
 */

public class Constant {
    public static String HOST_NAME = "http://api.smartcheck.vn";
    public static String SMARTCHECK_STORE_URL = "https://play.google.com/store/apps/details?id=com.collalab.smartcheck";
    public static String SMARTCHECK_STORE_THUMBNAIL = "https://lh3.googleusercontent.com/frDnqU_sJxKmwDPrwhZxRSQ5Lr2xM_Lia743GRBAgJz6BFjsEngzN46peEDyhE8UzEQ=w300";
    public static int I_AM_ANDROID = 1;
}
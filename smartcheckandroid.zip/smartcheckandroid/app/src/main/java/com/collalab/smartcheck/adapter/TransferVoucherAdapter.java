package com.collalab.smartcheck.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.collalab.smartcheck.R;
import com.collalab.smartcheck.common.Constant;
import com.collalab.smartcheck.model.TransferVoucher;
import com.squareup.picasso.Picasso;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class TransferVoucherAdapter extends RecyclerView.Adapter<TransferVoucherAdapter.VoucherViewHolder> {

    private List<TransferVoucher> voucherList;
    private Context mContext;

    public void setOnVoucherItemListener(OnVoucherItemListener onVoucherItemListener) {
        this.onVoucherItemListener = onVoucherItemListener;
    }

    OnVoucherItemListener onVoucherItemListener;

    public interface OnVoucherItemListener {
        void onClick(int position);

        void onBuy(int position);
    }

    public class VoucherViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.btn_favorite)
        ImageView btnFavorite;
        @BindView(R.id.tv_voucher)
        TextView tvVoucher;
        @BindView(R.id.tv_point_price)
        TextView tvVoucherPrice;
        @BindView(R.id.btn_buy_reward)
        TextView textCode;
        @BindView(R.id.img_voucher)
        ImageView imgVoucher;

        public VoucherViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }
    }

    public TransferVoucherAdapter(Context context, List<TransferVoucher> voucherList) {
        this.mContext = context;
        this.voucherList = voucherList;
    }

    @Override
    public VoucherViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_transfer_voucher_item, parent, false);

        return new VoucherViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(VoucherViewHolder holder, final int position) {

        TransferVoucher voucher = voucherList.get(position);

        if (!TextUtils.isEmpty(voucher.getVoucherName())) {
            holder.tvVoucher.setText(voucher.getVoucherName());
        }

        if (voucher.getPoints() != null) {
            holder.tvVoucherPrice.setText(String.valueOf(voucher.getPoints()) + " " + mContext.getResources().getString(R.string.string_voucher_point));
        }

        if (!TextUtils.isEmpty(voucher.getVoucherImage())) {
            Picasso.with(mContext).load(Constant.HOST_NAME + voucher.getVoucherImage()).placeholder(R.drawable.no_image_holder).into(holder.imgVoucher);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onVoucherItemListener != null) {
                    onVoucherItemListener.onClick(position);
                }
            }
        });

    }

    public void setVoucherList(List<TransferVoucher> voucherList) {
        this.voucherList = voucherList;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return voucherList == null ? 0 : voucherList.size();
    }
}
package com.collalab.smartcheck.fragment;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.SpannableStringBuilder;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.collalab.smartcheck.R;
import com.collalab.smartcheck.activity.BaseActivity;
import com.collalab.smartcheck.networking.ApiClient;
import com.collalab.smartcheck.networking.ApiInterface;
import com.collalab.smartcheck.widget.LoadingDialog;

import retrofit2.Call;
import retrofit2.Callback;

import static android.content.Context.INPUT_METHOD_SERVICE;

public class BaseFragment extends Fragment {
    Dialog mLoadingDialog;

    Dialog dialog;
    ImageView mIconMessage;
    TextView mTextViewMessage;

    protected ApiInterface apiService;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        apiService = ApiClient.getClient().create(ApiInterface.class);

    }

    protected void doRewardPoint(String userId, String type, String point, Callback<String> callback) {
        Call<String> call = apiService.bonusPoints(userId, type, point);
        call.enqueue(callback);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        buildMessageDialog();
    }

    private void buildMessageDialog() {
        if (dialog == null) {
            dialog = new Dialog(getContext());

            dialog.getWindow()
                    .getAttributes().windowAnimations = R.style.DialogAnimation;

            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.layout_message_dialog);

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(dialog.getWindow().getAttributes());
            lp.width = WindowManager.LayoutParams.MATCH_PARENT;
            dialog.getWindow().setAttributes(lp);

            mIconMessage = (ImageView) dialog.findViewById(R.id.ivIconMessage);
            mTextViewMessage = (TextView) dialog.findViewById(R.id.tvMessage);
        }
    }

    protected void showLoadingProgress() {
        if (mLoadingDialog != null && !mLoadingDialog.isShowing()) {
            mLoadingDialog.show();
        }
    }

    protected void hideLoadingProgress() {
        if (mLoadingDialog != null && mLoadingDialog.isShowing()) {
            mLoadingDialog.dismiss();
        }
    }

    protected void showMessageDialog() {
        if (dialog != null && !dialog.isShowing()) {
            dialog.show();
        }
    }

    public void showSuccessMessage(String content) {
        mIconMessage.setImageResource(R.drawable.ic_success_msg);
        mTextViewMessage.setText(content);
        showMessageDialog();
    }

    public void showShareFacebookSuccess(SpannableStringBuilder spannableStringBuilder) {
        mIconMessage.setImageResource(R.drawable.ic_coin_big);
        mTextViewMessage.setText(spannableStringBuilder);
        showMessageDialog();
    }

    public void showErrorMessage(String content) {
        mIconMessage.setImageResource(R.drawable.error_icon);
        mTextViewMessage.setText(content);
        showMessageDialog();
    }

    public void showOnCancelShareFb(String content) {
        mIconMessage.setImageResource(R.drawable.ic_info_msg);
        mTextViewMessage.setText(content);
        showMessageDialog();
    }

    protected void buildProgressDialog() {
        if (mLoadingDialog == null) {
            mLoadingDialog = LoadingDialog.createProgress(getContext());
        } else {
            mLoadingDialog.dismiss();
            mLoadingDialog = LoadingDialog.createProgress(getContext());
        }
        mLoadingDialog.setCanceledOnTouchOutside(false);
        mLoadingDialog.setOnKeyListener(keylistener);
    }

    DialogInterface.OnKeyListener keylistener = new DialogInterface.OnKeyListener() {
        public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
            if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
                return true;
            } else {
                return false;
            }
        }
    };

    public boolean isConnected() {
        ConnectivityManager
                cm = (ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isConnectedOrConnecting();
    }
}

package com.collalab.smartcheck.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class PrizeDetail implements Serializable {

    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("image")
    @Expose
    private String image;
    @SerializedName("money")
    @Expose
    private String money;
    @SerializedName("quantity")
    @Expose
    private String quantity;
    @SerializedName("from_date")
    @Expose
    private String fromDate;
    @SerializedName("to_date")
    @Expose
    private String toDate;
    @SerializedName("big_image")
    @Expose
    private String bigImage;
    @SerializedName("image1")
    @Expose
    private String image1;
    @SerializedName("image2")
    @Expose
    private String image2;
    @SerializedName("image3")
    @Expose
    private String image3;
    @SerializedName("des")
    @Expose
    private String des;

    /**
     * No args constructor for use in serialization
     */
    public PrizeDetail() {
    }

    /**
     * @param des
     * @param image2
     * @param image1
     * @param fromDate
     * @param name
     * @param money
     * @param image
     * @param quantity
     * @param toDate
     * @param bigImage
     * @param image3
     */
    public PrizeDetail(String name, String image, String money, String quantity, String fromDate, String toDate, String bigImage, String image1, String image2, String image3, String des) {
        super();
        this.name = name;
        this.image = image;
        this.money = money;
        this.quantity = quantity;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.bigImage = bigImage;
        this.image1 = image1;
        this.image2 = image2;
        this.image3 = image3;
        this.des = des;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public String getBigImage() {
        return bigImage;
    }

    public void setBigImage(String bigImage) {
        this.bigImage = bigImage;
    }

    public String getImage1() {
        return image1;
    }

    public void setImage1(String image1) {
        this.image1 = image1;
    }

    public String getImage2() {
        return image2;
    }

    public void setImage2(String image2) {
        this.image2 = image2;
    }

    public String getImage3() {
        return image3;
    }

    public void setImage3(String image3) {
        this.image3 = image3;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

}

package com.collalab.smartcheck.listener;

/**
 * Created by VietMac on 11/5/17.
 */

public interface OnChangePointListener {
    void onChangePoint(String newPoint);
}
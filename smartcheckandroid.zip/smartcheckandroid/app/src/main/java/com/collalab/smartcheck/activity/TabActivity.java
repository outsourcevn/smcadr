package com.collalab.smartcheck.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.collalab.smartcheck.R;
import com.collalab.smartcheck.adapter.ViewPagerAdapter;
import com.collalab.smartcheck.common.IntentRequestCode;
import com.collalab.smartcheck.event.EventChangePoint;
import com.collalab.smartcheck.event.EventFacebookAvatar;
import com.collalab.smartcheck.fragment.RewardFragment;
import com.collalab.smartcheck.fragment.ScanCodeFragment;
import com.collalab.smartcheck.fragment.ShareFragment;
import com.collalab.smartcheck.listener.OnChangePointListener;
import com.collalab.smartcheck.model.BonusPoint;
import com.collalab.smartcheck.model.PointConfig;
import com.collalab.smartcheck.model.RequestResponse;
import com.collalab.smartcheck.model.UserInfo;
import com.collalab.smartcheck.networking.ApiClient;
import com.collalab.smartcheck.networking.ApiInterface;
import com.collalab.smartcheck.persistence.PreferenceUtils;
import com.collalab.smartcheck.persistence.PrefsKey;
import com.collalab.smartcheck.utils.DataParser;
import com.squareup.picasso.Picasso;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.Calendar;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TabActivity extends BaseActivity {

    @BindView(R.id.drawer_layout)
    DrawerLayout mDrawerLayout;
    @BindView(R.id.nav_view)
    NavigationView mNavigationView;
    @BindView(R.id.view_pager)
    ViewPager mViewpager;

    @BindView(R.id.tv_title)
    TextView mTvTitle;

    @BindView(R.id.layout_bottom_bar_reward)
    LinearLayout mLayoutBottomReward;
    @BindView(R.id.layout_bottom_bar_scan)
    RelativeLayout mLayoutBottomScan;
    @BindView(R.id.layout_bottom_bar_share)
    LinearLayout mLayoutBottomShare;

    @BindView(R.id.tv_username)
    TextView mTvUserName;
    @BindView(R.id.tv_user_point)
    TextView mTvUserPoint;
    @BindView(R.id.tv_total_point)
    TextView mTvTitleBarPoint;

    @BindView(R.id.imv_avatar)
    ImageView mUserAvatar;

    ApiInterface apiService;
    String mUserId;
    UserInfo mUserInfo;

    PointConfig mPointConfig;

    boolean isOnResume;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab);

        ButterKnife.bind(this);
        apiService = ApiClient.getClient().create(ApiInterface.class);
        PreferenceUtils.init(this);

        getPointConfig();

        getLastUpdateUserInfo();

        getAndSetUserFacebookAvatar();

        mUserId = PreferenceUtils.getString(PrefsKey.KEY_USER_ID, null);
        if (TextUtils.isEmpty(mUserId)) {
            PreferenceUtils.logOut();
            Intent intent = new Intent(this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } else {
            getUserInfo(true);
        }

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                setupViewPager(mViewpager);

                selectTab(1);
            }
        }, 200);

    }

    private void getAndSetUserFacebookAvatar() {
        String avatarUrl = PreferenceUtils.getString(PrefsKey.KEY_FACEBOOK_AVATAR_LINK,null);
        if(!TextUtils.isEmpty(avatarUrl)) {
            Picasso.with(this).load(avatarUrl).placeholder(R.drawable.ic_default_user).into(mUserAvatar);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(final EventChangePoint event) {
        if (event != null && !TextUtils.isEmpty(event.newPoint)) {
            mTvUserPoint.setText(event.newPoint);
            mTvTitleBarPoint.setText(event.newPoint);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(final EventFacebookAvatar event) {
        if (event != null && !TextUtils.isEmpty(event.avatarUrl)) {
            Picasso.with(this).load(event.avatarUrl).placeholder(R.drawable.ic_default_user).into(mUserAvatar);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!isOnResume) {
            isOnResume = true;
        } else {
            getUserInfo(false);
        }

    }

    private void getLastUpdateUserInfo() {
        //Preset user info with last update
        String rawUserInfo = PreferenceUtils.getString(PrefsKey.KEY_USER_INFO, null);
        if (!TextUtils.isEmpty(rawUserInfo)) {
            mUserInfo = DataParser.getUserInfo(rawUserInfo);
            logUser(mUserInfo.getUserPhone(), mUserInfo.getUserEmail());
            bindUserInfoToView();
        }
    }

    @OnClick(R.id.iv_hamburger)
    public void onHamburgerClick() {
        if (!mDrawerLayout.isDrawerOpen(Gravity.LEFT)) {
            mDrawerLayout.openDrawer(Gravity.LEFT);
        }
    }

    @OnClick(R.id.tv_edit_user)
    public void onEditUserInfo() {
        Intent intent = new Intent(TabActivity.this, EditUserInfoActivity.class);
        intent.putExtra(PrefsKey.KEY_USER_INFO, mUserInfo);
        startActivity(intent);
    }

    @OnClick(R.id.layout_nav_reward)
    public void onReward() {
        if (mDrawerLayout.isDrawerOpen(Gravity.LEFT)) {
            mDrawerLayout.closeDrawer(Gravity.LEFT);
        }
        selectTab(0);
    }

    @OnClick(R.id.layout_nav_prize)
    public void onPrize() {
        Intent intent = new Intent(TabActivity.this, MyPrizeActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.layout_nav_history)
    public void onHistory() {
        Intent intent = new Intent(TabActivity.this, ScanHistoryActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.layout_nav_top_up)
    public void onTopUp() {
        Intent intent = new Intent(TabActivity.this, TopUpActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.layout_nav_help)
    public void onHelp() {
        Intent intent = new Intent(TabActivity.this, HelpActivity.class);
        startActivity(intent);
    }

    @OnClick(R.id.layout_nav_share)
    public void onShare() {
        if (mDrawerLayout.isDrawerOpen(Gravity.LEFT)) {
            mDrawerLayout.closeDrawer(Gravity.LEFT);
        }
        selectTab(2);
    }

    @OnClick(R.id.layout_nav_logout)
    public void onLogOut() {
        PreferenceUtils.logOut();
        Intent intent = new Intent(TabActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivityForResult(intent, IntentRequestCode.INTENT_EDIT_USER_INFO);
    }

    @OnClick(R.id.layout_bottom_bar_reward)
    public void onBottomReward() {
        selectTab(0);
    }

    @OnClick(R.id.layout_bottom_bar_scan)
    public void onBottomScan() {
        selectTab(1);
    }

    @OnClick(R.id.layout_bottom_bar_share)
    public void onBottomShare() {
        selectTab(2);
    }

    private void selectTab(int index) {

        mViewpager.setCurrentItem(index);

        invalidateBottomBarView(index);
    }

    private void invalidateBottomBarView(int index) {
        if (index == 0) {
            mLayoutBottomReward.setBackgroundColor(ContextCompat.getColor(this, R.color.color_app_main_dark));
            mLayoutBottomShare.setBackgroundColor(ContextCompat.getColor(this, R.color.color_app_main));
        } else if (index == 1) {
            mLayoutBottomReward.setBackgroundColor(ContextCompat.getColor(this, R.color.color_app_main));
            mLayoutBottomShare.setBackgroundColor(ContextCompat.getColor(this, R.color.color_app_main));
        } else if (index == 2) {
            mLayoutBottomReward.setBackgroundColor(ContextCompat.getColor(this, R.color.color_app_main));
            mLayoutBottomShare.setBackgroundColor(ContextCompat.getColor(this, R.color.color_app_main_dark));
        }
    }

    private void setupViewPager(ViewPager viewPager) {

        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        ScanCodeFragment scanCodeFragment = new ScanCodeFragment();
        scanCodeFragment.setOnChangePointListener(mOnChangePointListener);

        final ShareFragment shareFragment = new ShareFragment();
        shareFragment.setOnChangePointListener(mOnChangePointListener);

        RewardFragment rewardFragment = new RewardFragment();
        rewardFragment.setOnChangePointListener(mOnChangePointListener);

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {

                invalidateBottomBarView(position);

                switch (position) {
                    case 0:
                        mTvTitle.setText(getResources().getString(R.string.string_menu_reward));
                        shareFragment.setUserVisibleHint(false);
                        break;
                    case 1:
                        mTvTitle.setText(getResources().getString(R.string.string_scan_code));
                        shareFragment.setUserVisibleHint(false);
                        break;
                    case 2:
                        mTvTitle.setText(getResources().getString(R.string.string_menu_share));
                        shareFragment.setUserVisibleHint(true);
                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        adapter.addFragment(rewardFragment);
        adapter.addFragment(scanCodeFragment);
        adapter.addFragment(shareFragment);
        viewPager.setAdapter(adapter);

    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(Gravity.LEFT)) {
            mDrawerLayout.closeDrawer(Gravity.LEFT);
        } else {
//            if (!mSearchView.isIconified()) {
//                mSearchView.setIconified(true);
//            } else {
//                super.onBackPressed();
//            }
            super.onBackPressed();
        }
    }

    private void bindUserInfoToView() {
        if (mUserInfo != null) {
            if (!TextUtils.isEmpty(mUserInfo.getUserName())) {
                mTvUserName.setText(mUserInfo.getUserName());
            } else if (!TextUtils.isEmpty(mUserInfo.getUserPhone())) {
                mTvUserName.setText(mUserInfo.getUserPhone());
            } else if (!TextUtils.isEmpty(mUserInfo.getUserEmail())) {
                mTvUserName.setText(mUserInfo.getUserEmail());
            } else {
                mTvUserName.setText("SmartCheck");
            }

            if (!TextUtils.isEmpty(mUserInfo.getPoints())) {
                mTvUserPoint.setText(mUserInfo.getPoints());
                mTvTitleBarPoint.setText(mUserInfo.getPoints());
            } else {
                mTvUserPoint.setText("0");
                mTvTitleBarPoint.setText("0");
            }
        }
    }

    //Network Request

    private void getUserInfo(boolean showLoadingIncicator) {
        if (showLoadingIncicator) {
            buildProgressDialog();
            showLoadingProgress();
        }

        Call<String> call = apiService.getUserInfo(mUserId);
        call.enqueue(mUserInfoCallBack);
    }

    Callback<String> mUserInfoCallBack = new Callback<String>() {
        @Override
        public void onResponse(Call<String> call, Response<String> response) {
            RequestResponse requestResponse = DataParser.getResponse(response.body());
            if (requestResponse.isSuccess()) {
                mUserInfo = DataParser.getUserInfo(response.body());
                if (mUserInfo != null) {
                    logUser(mUserInfo.getUserPhone(), mUserInfo.getUserEmail());
                    PreferenceUtils.commitString(PrefsKey.KEY_USER_INFO, response.body());
                }
                bindUserInfoToView();
            } else {
                Toast.makeText(TabActivity.this, requestResponse.getMessage(), Toast.LENGTH_SHORT).show();
            }
            hideLoadingProgress();
        }

        @Override
        public void onFailure(Call<String> call, Throwable t) {
            hideLoadingProgress();
        }
    };

    private void getPointConfig() {
        Call<String> call = apiService.getConfigPoints();
        call.enqueue(mPoinConfigCallBack);
    }

    Callback<String> mPoinConfigCallBack = new Callback<String>() {
        @Override
        public void onResponse(Call<String> call, Response<String> response) {
            RequestResponse requestResponse = DataParser.getResponse(response.body());
            if (requestResponse.isSuccess()) {
                PointConfig pointConfig = DataParser.parsePointConfig(response.body());
                if (pointConfig != null) {
                    PreferenceUtils.commitString(PrefsKey.KEY_POINT_CONFIG, response.body());
                }
            }

            checkCurrentMonthAndReward();
        }

        @Override
        public void onFailure(Call<String> call, Throwable t) {
            hideLoadingProgress();
        }
    };

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_OK) {
            switch (requestCode) {
                case IntentRequestCode.INTENT_EDIT_USER_INFO:
                    invalidateViewFromIntentData();
                    break;
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {

            case MY_PERMISSIONS_REQUEST_CAMERA:
                if (grantResults.length == 2) {

                    boolean locationPermission = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean cameraPermission = grantResults[1] == PackageManager.PERMISSION_GRANTED;

                    if (locationPermission) {
                        startLocation();
                    }
                    if (cameraPermission) {
                        resumeDisplayCameraToScan();
                    }
                } else if (grantResults.length == 1) {
                    if (Manifest.permission.ACCESS_FINE_LOCATION.equalsIgnoreCase(permissions[0])) {
                        startLocation();
                    } else {
                        resumeDisplayCameraToScan();
                    }
                }

                break;
        }
    }

    private void resumeDisplayCameraToScan() {
        //TODO notify to fragment that now can request camera
    }

    private void invalidateViewFromIntentData() {
        if (getIntent() != null && getIntent().getExtras() != null && getIntent().getExtras().containsKey(PrefsKey.KEY_USER_INFO)) {
            mUserInfo = (UserInfo) getIntent().getExtras().getSerializable(PrefsKey.KEY_USER_INFO);
            bindUserInfoToView();
        }
    }

    OnChangePointListener mOnChangePointListener = new OnChangePointListener() {
        @Override
        public void onChangePoint(String newPoint) {
            if (!TextUtils.isEmpty(newPoint)) {
                mTvUserPoint.setText(newPoint);
                mTvTitleBarPoint.setText(newPoint);

                getUserInfo(false);
            }
        }
    };

    private void checkCurrentMonthAndReward() {
        long timeMilli = PreferenceUtils.getLong(PrefsKey.KEY_CURRENT_DATE_REWARD, 0);
        if (timeMilli != 0) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(timeMilli);
            Calendar currentCalendar = Calendar.getInstance();
            if (calendar.get(Calendar.YEAR) == currentCalendar.get(Calendar.YEAR) && calendar.get(Calendar.MONTH) == currentCalendar.get(Calendar.MONTH)) {
                Log.i("TabActivity", "Da cong tien cho thang nay roi");
            } else {
                addBonusPointForInstallTime();
            }
        } else {
            addBonusPointForInstallTime();
        }
    }

    private void addBonusPointForInstallTime() {
        PreferenceUtils.commitLong(PrefsKey.KEY_CURRENT_DATE_REWARD, new Date().getTime());
        mPointConfig = DataParser.parsePointConfig(PreferenceUtils.getString(PrefsKey.KEY_POINT_CONFIG, null));
        if (mPointConfig != null) {
            Call<String> call = apiService.bonusPoints(mUserId, BonusPoint.USED_MONTH, mPointConfig.getTimePoint());
            call.enqueue(mAddBonusPointCallBack);
        }
    }

    Callback<String> mAddBonusPointCallBack = new Callback<String>() {
        @Override
        public void onResponse(Call<String> call, Response<String> response) {
            String totalPoint = DataParser.getTotalPoint(response.body());
            if (!TextUtils.isEmpty(totalPoint)) {
                if (mOnChangePointListener != null) {
                    mOnChangePointListener.onChangePoint(totalPoint);
                }
            }
        }

        @Override
        public void onFailure(Call<String> call, Throwable t) {
            hideLoadingProgress();
        }
    };
}

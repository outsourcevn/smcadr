package com.collalab.smartcheck.utils;

import android.graphics.Point;

import com.collalab.smartcheck.model.PointConfig;
import com.collalab.smartcheck.model.Prize;
import com.collalab.smartcheck.model.PrizeDetail;
import com.collalab.smartcheck.model.ProductScan;
import com.collalab.smartcheck.model.RequestResponse;
import com.collalab.smartcheck.model.Scan;
import com.collalab.smartcheck.model.Transfer;
import com.collalab.smartcheck.model.TransferVoucher;
import com.collalab.smartcheck.model.UserInfo;
import com.collalab.smartcheck.model.Voucher;
import com.collalab.smartcheck.model.VoucherDetail;
import com.collalab.smartcheck.persistence.PreferenceUtils;
import com.collalab.smartcheck.persistence.PrefsKey;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by VietMac on 11/4/17.
 */

public class DataParser {
    public static RequestResponse getResponse(String json) {
        try {
            RequestResponse entity = new Gson().fromJson(json, RequestResponse.class);
            return entity;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static UserInfo getUserInfo(String json) {
        try {

            JSONObject jsonObject = new JSONObject(json);
            if (jsonObject.has("data") && jsonObject.getJSONArray("data").length() > 0) {

                JSONObject idObject = (JSONObject) jsonObject.getJSONArray("data").get(0);
                UserInfo entity = new Gson().fromJson(idObject.toString(), UserInfo.class);

                return entity;
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static VoucherDetail parseVoucherDetail(String json) {
        try {

            JSONObject jsonObject = new JSONObject(json);
            if (jsonObject.has("data") && jsonObject.getJSONArray("data").length() > 0) {

                JSONObject idObject = (JSONObject) jsonObject.getJSONArray("data").get(0);
                VoucherDetail entity = new Gson().fromJson(idObject.toString(), VoucherDetail.class);

                return entity;
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static ArrayList<Voucher> parseVoucherList(String json) {
        try {
            JSONObject jsonObject = new JSONObject(json);
            if (jsonObject.has("data") && jsonObject.getJSONArray("data").length() > 0) {

                JSONObject idObject = (JSONObject) jsonObject.getJSONArray("data").get(0);
                if (idObject != null && idObject.getJSONArray("list").length() > 0) {
                    List<Voucher> entityList = Arrays.asList(new Gson().fromJson(idObject.getJSONArray("list").toString(), Voucher[].class));
                    return new ArrayList<>(entityList);
                }
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static ArrayList<TransferVoucher> parseTransferVoucherList(String json) {
        try {
            JSONObject jsonObject = new JSONObject(json);
            if (jsonObject.has("data") && jsonObject.getJSONArray("data").length() > 0) {

                JSONObject idObject = (JSONObject) jsonObject.getJSONArray("data").get(0);
                if (idObject != null && idObject.getJSONArray("list").length() > 0) {
                    List<TransferVoucher> entityList = Arrays.asList(new Gson().fromJson(idObject.getJSONArray("list").toString(), TransferVoucher[].class));
                    return new ArrayList<>(entityList);
                }
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static ArrayList<ProductScan> parseScanHistoryList(String json) {
        try {
            JSONObject jsonObject = new JSONObject(json);
            if (jsonObject.has("data") && jsonObject.getJSONArray("data").length() > 0) {

                JSONObject idObject = (JSONObject) jsonObject.getJSONArray("data").get(0);
                if (idObject != null && idObject.getJSONArray("list").length() > 0) {
                    List<ProductScan> entityList = Arrays.asList(new Gson().fromJson(idObject.getJSONArray("list").toString(), ProductScan[].class));
                    return new ArrayList<>(entityList);
                }
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static ArrayList<Prize> parseMyPrizeList(String json) {
        try {
            JSONObject jsonObject = new JSONObject(json);
            if (jsonObject.has("data") && jsonObject.getJSONArray("data").length() > 0) {

                JSONObject idObject = (JSONObject) jsonObject.getJSONArray("data").get(0);
                if (idObject != null && idObject.getJSONArray("list").length() > 0) {
                    List<Prize> entityList = Arrays.asList(new Gson().fromJson(idObject.getJSONArray("list").toString(), Prize[].class));
                    return new ArrayList<>(entityList);
                }
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static PrizeDetail parsePrizeDetail(String json) {
        try {

            JSONObject jsonObject = new JSONObject(json);
            if (jsonObject.has("data") && jsonObject.getJSONArray("data").length() > 0) {

                JSONObject idObject = (JSONObject) jsonObject.getJSONArray("data").get(0);
                PrizeDetail entity = new Gson().fromJson(idObject.toString(), PrizeDetail.class);

                return entity;
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Scan parseOneScan(String json) {
        try {

            JSONObject jsonObject = new JSONObject(json);
            if (jsonObject.has("data") && jsonObject.getJSONArray("data").length() > 0) {

                JSONObject idObject = (JSONObject) jsonObject.getJSONArray("data").get(0);
                Scan entity = new Gson().fromJson(idObject.toString(), Scan.class);

                return entity;
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static PointConfig parsePointConfig(String json) {
        try {

            JSONObject jsonObject = new JSONObject(json);
            if (jsonObject.has("data") && jsonObject.getJSONArray("data").length() > 0) {

                JSONObject idObject = (JSONObject) jsonObject.getJSONArray("data").get(0);
                PointConfig entity = new Gson().fromJson(idObject.toString(), PointConfig.class);

                return entity;
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static Transfer parseTransferVoucher(String json) {
        try {

            JSONObject jsonObject = new JSONObject(json);
            if (jsonObject.has("data") && jsonObject.getJSONArray("data").length() > 0) {

                JSONObject idObject = (JSONObject) jsonObject.getJSONArray("data").get(0);
                Transfer entity = new Gson().fromJson(idObject.toString(), Transfer.class);

                return entity;
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String getTotalPoint(String json) {
        try {

            JSONObject jsonObject = new JSONObject(json);
            if (jsonObject.has("data") && jsonObject.getJSONArray("data").length() > 0) {

                JSONObject idObject = (JSONObject) jsonObject.getJSONArray("data").get(0);
                if (idObject.has("total")) {
                    return idObject.getString("total");
                }
                return null;
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}

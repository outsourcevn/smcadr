package com.collalab.smartcheck.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.collalab.smartcheck.R;
import com.collalab.smartcheck.adapter.ViewPagerAdapter;
import com.collalab.smartcheck.listener.OnChangePointListener;

import butterknife.BindView;
import butterknife.ButterKnife;

public class RewardFragment extends Fragment {

    @BindView(R.id.tabs)
    TabLayout mTabLayout;
    @BindView(R.id.viewpager)
    ViewPager mViewPager;
    OnChangePointListener mOnChangePointListener;

    public RewardFragment() {
        // Required empty public constructor
    }

    public static RewardFragment newInstance() {
        RewardFragment fragment = new RewardFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_reward, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setupViewPager(mViewPager);
        setupTabIcons();
    }

    private void setupViewPager(final ViewPager viewPager) {
        final ViewPagerAdapter adapter = new ViewPagerAdapter(getChildFragmentManager());

        MyRewardFragment myRewardFragment = new MyRewardFragment();
        myRewardFragment.setOnChangePointListener(mOnChangePointListener);

        VoucherListFragment voucherListFragment = new VoucherListFragment();
        voucherListFragment.setOnChangePointListener(mOnChangePointListener);

        adapter.addFragment(new MyRewardFragment());
        adapter.addFragment(voucherListFragment);
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if (position == 0) {
                    adapter.getItem(1).setUserVisibleHint(false);
                } else {
                    adapter.getItem(0).setUserVisibleHint(false);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private void setupTabIcons() {
        mTabLayout.setupWithViewPager(mViewPager);
        String[] listTitle = {getContext().getResources().getString(R.string.string_my_reward), getContext().getResources().getString(R.string.string_voucher_catalogue)};
        for (int i = 0; i < mTabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = mTabLayout.getTabAt(i);
            tab.setText(listTitle[i]);
        }
    }

    public void setOnChangePointListener(OnChangePointListener onChangePointListener) {
        this.mOnChangePointListener = onChangePointListener;
    }

}

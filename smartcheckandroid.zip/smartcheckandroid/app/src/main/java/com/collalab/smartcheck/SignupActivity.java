package com.collalab.smartcheck;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.collalab.smartcheck.networking.ApiClient;
import com.collalab.smartcheck.networking.ApiInterface;
import com.collalab.smartcheck.persistence.PreferenceUtils;
import com.collalab.smartcheck.persistence.PrefsKey;

import org.json.JSONObject;

import butterknife.ButterKnife;
import butterknife.Bind;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignupActivity extends AppCompatActivity {
    private static final String TAG = "SignupActivity";

    @Bind(R.id.input_name)
    EditText _nameText;
    @Bind(R.id.input_email)
    EditText _emailText;
    @Bind(R.id.input_mobile)
    EditText _mobileText;
    @Bind(R.id.input_password)
    EditText _passwordText;
    @Bind(R.id.input_reEnterPassword)
    EditText _reEnterPasswordText;
    @Bind(R.id.confirm_input_mobile)
    EditText edtConfirmPhone;
    @Bind(R.id.btn_signup)
    Button _signupButton;
    @Bind(R.id.btn_confirm)
    Button btnConfirm;
    @Bind(R.id.link_login)
    TextView _loginLink;

    @Bind(R.id.layout_confirm_phone)
    View layoutConfirmPhone;
    @Bind(R.id.layout_signup_info)
    View layoutSignUpInfo;

    ApiInterface apiService;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        ButterKnife.bind(this);

        apiService = ApiClient.getClient().create(ApiInterface.class);

        _signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signup();
            }
        });

        _loginLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Finish the registration screen and return to the Login activity
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                finish();
                overridePendingTransition(R.anim.push_left_in, R.anim.push_left_out);
            }
        });
    }

    private void toggleConfirmLayout(boolean isShowConfirm) {
        if (isShowConfirm) {
            layoutSignUpInfo.setVisibility(View.GONE);
            layoutConfirmPhone.setVisibility(View.VISIBLE);
            _signupButton.setEnabled(false);
        } else {
            layoutSignUpInfo.setVisibility(View.VISIBLE);
            layoutConfirmPhone.setVisibility(View.GONE);
            _signupButton.setEnabled(true);
        }
    }

    @OnClick(R.id.btn_confirm)
    public void onClickConfirm() {
        String mobile = _mobileText.getText().toString().trim();
        String confirmMobile = edtConfirmPhone.getText().toString().trim();

        if (confirmMobile.isEmpty() && !TextUtils.isDigitsOnly(confirmMobile)) {
            edtConfirmPhone.setError(getResources().getString(R.string.string_mobile_validation));
            return;
        } else {
            edtConfirmPhone.setError(null);
        }

        if (mobile.equalsIgnoreCase(confirmMobile)) {
            doSignUpNetwork();
        } else {
            displayMessage(getResources().getString(R.string.string_confirm_phone_error));
        }
    }

    public void signup() {
        Log.d(TAG, "Signup");

        if (!validate()) {
            onSignupFailed();
            return;
        }

        toggleConfirmLayout(true);
    }

    private void doSignUpNetwork() {
        String name = _nameText.getText().toString();
        String email = _emailText.getText().toString();
        String mobile = _mobileText.getText().toString();
        String password = _passwordText.getText().toString();
        String reEnterPassword = _reEnterPasswordText.getText().toString();

        Call<String> call = apiService.registerAccount(name, email, mobile, password, "0", String.valueOf(KeyGenerator.generateKey()));
        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                Log.i("SmartCheck", response.body().toString());
                if (!TextUtils.isEmpty(response.body().toString())) {
                    try {
                        JSONObject jsonObject = new JSONObject(response.body().toString());
                        if (jsonObject.has("status") && "success".equalsIgnoreCase(jsonObject.getString("status"))) {
                            Toast.makeText(SignupActivity.this, String.valueOf(jsonObject.getString("message")), Toast.LENGTH_SHORT).show();

                            if (jsonObject.has("data") && jsonObject.getJSONArray("data").length() > 0) {
                                JSONObject idObject = (JSONObject) jsonObject.getJSONArray("data").get(0);

                                if (idObject.has("user_id")) {
                                    PreferenceUtils.commitString(PrefsKey.KEY_USER_ID, String.valueOf(idObject.getString("user_id")));
                                }
                            }

                            PreferenceUtils.commitBoolean(PrefsKey.KEY_IS_LOGGED_IN, true);
                            Intent intent = new Intent(SignupActivity.this, MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        } else if (jsonObject.has("status") && "failed".equalsIgnoreCase(jsonObject.getString("status"))) {
                            _signupButton.setEnabled(true);
                            Toast.makeText(SignupActivity.this, String.valueOf(jsonObject.getString("message")), Toast.LENGTH_SHORT).show();
                            toggleConfirmLayout(false);
                        }
                    } catch (Exception e) {
                        Toast.makeText(SignupActivity.this, getResources().getString(R.string.string_sign_up_failed), Toast.LENGTH_SHORT).show();
                        _signupButton.setEnabled(true);
                        toggleConfirmLayout(false);
                    }
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                _signupButton.setEnabled(true);
                Toast.makeText(SignupActivity.this, getResources().getString(R.string.string_sign_up_failed), Toast.LENGTH_SHORT).show();
                toggleConfirmLayout(false);
            }
        });
    }

    public void onSignupFailed() {
        Toast.makeText(getBaseContext(), getResources().getString(R.string.string_sign_up_failed), Toast.LENGTH_LONG).show();
        _signupButton.setEnabled(true);
    }

    public boolean validate() {
        boolean valid = true;

        String name = _nameText.getText().toString();
        String email = _emailText.getText().toString();
        String mobile = _mobileText.getText().toString();
        String password = _passwordText.getText().toString();
        String reEnterPassword = _reEnterPasswordText.getText().toString();

        if (TextUtils.isEmpty(name)) {
            _nameText.setError(getResources().getString(R.string.string_name_validation));
            valid = false;
        } else {
            _nameText.setError(null);
        }

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            _emailText.setError(getResources().getString(R.string.string_email_validation));
            valid = false;
        } else {
            _emailText.setError(null);
        }

        if (mobile.isEmpty() && !TextUtils.isDigitsOnly(mobile)) {
            _mobileText.setError(getResources().getString(R.string.string_mobile_validation));
            valid = false;
        } else {
            _mobileText.setError(null);
        }

        if (password.isEmpty() || password.length() < 6) {
            _passwordText.setError(getResources().getString(R.string.string_password_validation_msg));
            valid = false;
        } else {
            _passwordText.setError(null);
        }

        if (!(reEnterPassword.equals(password))) {
            _reEnterPasswordText.setError(getResources().getString(R.string.string_password_not_match));
            valid = false;
        } else {
            _reEnterPasswordText.setError(null);
        }

        return valid;
    }

    public void displayMessage(String message) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("Close", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        setFinishOnTouchOutside(false);
                        dialog.dismiss();
                        toggleConfirmLayout(false);
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        alertDialog.show();
    }

}
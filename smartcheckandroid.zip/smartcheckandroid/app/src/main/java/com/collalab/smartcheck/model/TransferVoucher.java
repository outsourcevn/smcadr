package com.collalab.smartcheck.model;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class TransferVoucher implements Serializable {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("user_id")
    @Expose
    private Integer userId;
    @SerializedName("user_name")
    @Expose
    private String userName;
    @SerializedName("user_email")
    @Expose
    private String userEmail;
    @SerializedName("user_phone")
    @Expose
    private String userPhone;
    @SerializedName("voucher_id")
    @Expose
    private Integer voucherId;
    @SerializedName("voucher_name")
    @Expose
    private String voucherName;
    @SerializedName("points")
    @Expose
    private Integer points;
    @SerializedName("date_time")
    @Expose
    private String dateTime;
    @SerializedName("lon")
    @Expose
    private Float lon;
    @SerializedName("lat")
    @Expose
    private Float lat;
    @SerializedName("address")
    @Expose
    private String address;
    @SerializedName("code")
    @Expose
    private String code;
    @SerializedName("voucher_image")
    @Expose
    private String voucherImage;

    /**
     * No args constructor for use in serialization
     */
    public TransferVoucher() {
    }

    /**
     * @param lon
     * @param dateTime
     * @param userEmail
     * @param code
     * @param id
     * @param address
     * @param userId
     * @param voucherName
     * @param userName
     * @param userPhone
     * @param points
     * @param lat
     * @param voucherId
     */
    public TransferVoucher(Integer id, Integer userId, String userName, String userEmail, String userPhone, Integer voucherId, String voucherName, Integer points, String dateTime, Float lon, Float lat, String address, String code) {
        super();
        this.id = id;
        this.userId = userId;
        this.userName = userName;
        this.userEmail = userEmail;
        this.userPhone = userPhone;
        this.voucherId = voucherId;
        this.voucherName = voucherName;
        this.points = points;
        this.dateTime = dateTime;
        this.lon = lon;
        this.lat = lat;
        this.address = address;
        this.code = code;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public Integer getVoucherId() {
        return voucherId;
    }

    public void setVoucherId(Integer voucherId) {
        this.voucherId = voucherId;
    }

    public String getVoucherName() {
        return voucherName;
    }

    public void setVoucherName(String voucherName) {
        this.voucherName = voucherName;
    }

    public Integer getPoints() {
        return points;
    }

    public void setPoints(Integer points) {
        this.points = points;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public Float getLon() {
        return lon;
    }

    public void setLon(Float lon) {
        this.lon = lon;
    }

    public Float getLat() {
        return lat;
    }

    public void setLat(Float lat) {
        this.lat = lat;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getVoucherImage() {
        return voucherImage;
    }

    public void setVoucherImage(String voucherImage) {
        this.voucherImage = voucherImage;
    }
}

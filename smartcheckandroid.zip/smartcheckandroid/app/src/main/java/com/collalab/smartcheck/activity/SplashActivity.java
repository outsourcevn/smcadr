package com.collalab.smartcheck.activity;

import android.content.Intent;
import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.collalab.smartcheck.R;
import com.collalab.smartcheck.persistence.PreferenceUtils;
import com.collalab.smartcheck.persistence.PrefsKey;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_splash);
        PreferenceUtils.init(this);

        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (PreferenceUtils.getBoolean(PrefsKey.KEY_IS_LOGGED_IN, false)) {
                    SplashActivity.this.startActivity(new Intent(SplashActivity.this, TabActivity.class));
                    SplashActivity.this.finish();
                } else {
                    SplashActivity.this.startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                    SplashActivity.this.finish();
                }
            }
        }, 2000);
    }
}
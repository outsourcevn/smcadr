package com.collalab.smartcheck.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Voucher {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("image")
    @Expose
    private String image;
    @SerializedName("point")
    @Expose
    private Integer point;

    /**
     * No args constructor for use in serialization
     */
    public Voucher() {
    }

    /**
     * @param id
     * @param point
     * @param name
     * @param image
     */
    public Voucher(Integer id, String name, String image, Integer point) {
        super();
        this.id = id;
        this.name = name;
        this.image = image;
        this.point = point;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Integer getPoint() {
        return point;
    }

    public void setPoint(Integer point) {
        this.point = point;
    }

}

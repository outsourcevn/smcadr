package com.collalab.smartcheck.common;

/**
 * Created by VietMac on 11/4/17.
 */

public class IntentKey {
    public static String KEY_VOUCHER_ID = "key_voucher_id";
    public static String KEY_TRANSFER_VOUCHER = "key_transfer_voucher";
    public static String KEY_VOUCHER_DETAIL = "key_voucher_detail";
    public static String KEY_PRIZE_ID = "key_prize_id";
    public static String INTENT_KEY_LIST_IMG = "intent_key_list_img";
    public static String INTENT_KEY_IMG_INDEX = "intent_key_img_index";
    public static String INTENT_KEY_SHOW_CONGRATULATION = "key_intent_show_congratulation";
}

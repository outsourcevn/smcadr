package com.collalab.smartcheck.activity;

import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import com.collalab.smartcheck.R;
import com.collalab.smartcheck.adapter.ProductScanAdapter;
import com.collalab.smartcheck.model.ProductScan;
import com.collalab.smartcheck.model.RequestResponse;
import com.collalab.smartcheck.networking.ApiClient;
import com.collalab.smartcheck.networking.ApiInterface;
import com.collalab.smartcheck.persistence.PreferenceUtils;
import com.collalab.smartcheck.persistence.PrefsKey;
import com.collalab.smartcheck.utils.DataParser;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ScanHistoryActivity extends BaseActivity {

    ApiInterface apiService;
    String mUserId;
    ArrayList<ProductScan> mProductScanList;
    ProductScanAdapter mProductScanAdapter;

    @BindView(R.id.recycler_view)
    RecyclerView mRecyclerView;
    @BindView(R.id.swipe_refresh_layout)
    SwipeRefreshLayout mSwipeRefreshLayout;
    RecyclerView.LayoutManager mLayoutManager;
    @BindView(R.id.layout_empty)
    View mLayoutEmpty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_history);

        ButterKnife.bind(this);
        apiService = ApiClient.getClient().create(ApiInterface.class);
        PreferenceUtils.init(this);

        mUserId = PreferenceUtils.getString(PrefsKey.KEY_USER_ID, null);

        getListScannedCodeHistory();
        setUpRecyclerView();
        setUpSwipeLayout();
    }

    @OnClick(R.id.btn_back)
    public void onBackClick() {
        finish();
    }

    private void setUpRecyclerView() {
        mProductScanAdapter = new ProductScanAdapter(this, mProductScanList);
        mLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mProductScanAdapter);
    }

    private void setUpSwipeLayout() {
        mSwipeRefreshLayout.setColorSchemeColors(ContextCompat.getColor(this, R.color.color_actionbar));
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getListScannedCodeHistory();
            }
        });
    }

    private void hideProgressLoading() {
        if (mSwipeRefreshLayout.isRefreshing()) {
            mSwipeRefreshLayout.setRefreshing(false);
            hideLoadingProgress();
        } else {
            hideLoadingProgress();
        }
    }

    private void getListScannedCodeHistory() {

        if (!mSwipeRefreshLayout.isRefreshing()) {
            buildProgressDialog();
            showLoadingProgress();
        }

        Call<String> call = apiService.getHistoryCheckOfUser(mUserId);
        call.enqueue(mScanQrCodeHistoryCallBack);
    }

    Callback<String> mScanQrCodeHistoryCallBack = new Callback<String>() {
        @Override
        public void onResponse(Call<String> call, Response<String> response) {
            RequestResponse requestResponse = DataParser.getResponse(response.body());
            if (requestResponse.isSuccess()) {
                mProductScanList = DataParser.parseScanHistoryList(response.body());
                showListProductScanned();
            } else {
                Toast.makeText(ScanHistoryActivity.this, requestResponse.getMessage(), Toast.LENGTH_SHORT).show();
            }
            hideProgressLoading();
        }

        @Override
        public void onFailure(Call<String> call, Throwable t) {
            hideProgressLoading();
        }
    };

    private void showListProductScanned() {
        if(mProductScanList != null && mProductScanList.size() > 0) {
            mProductScanAdapter.setProductScanList(mProductScanList);
            mLayoutEmpty.setVisibility(View.GONE);
        } else {
            mLayoutEmpty.setVisibility(View.VISIBLE);
        }
    }
}

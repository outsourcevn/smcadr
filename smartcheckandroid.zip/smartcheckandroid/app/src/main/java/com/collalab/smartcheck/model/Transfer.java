package com.collalab.smartcheck.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Transfer {

    @SerializedName("total")
    @Expose
    private String total;
    @SerializedName("code")
    @Expose
    private String code;

    /**
     * No args constructor for use in serialization
     */
    public Transfer() {
    }

    /**
     * @param total
     * @param code
     */
    public Transfer(String total, String code) {
        super();
        this.total = total;
        this.code = code;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

}

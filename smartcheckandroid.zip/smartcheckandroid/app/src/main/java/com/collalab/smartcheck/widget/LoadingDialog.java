package com.collalab.smartcheck.widget;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.collalab.smartcheck.R;

/**
 * Created by VietMac on 2017-09-16.
 */

public class LoadingDialog {

    public static Dialog createProgress(Context context) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View loadingDialogLayout = inflater.inflate(R.layout.layout_loading_dialog, null);
        LinearLayout layout = (LinearLayout) loadingDialogLayout.findViewById(R.id.dialog_view);
        ImageView loadImage = (ImageView) loadingDialogLayout.findViewById(R.id.loading_image);
        Animation hyperspaceJumpAnimation = AnimationUtils.loadAnimation(context, R.anim.loading_animation);
        loadImage.startAnimation(hyperspaceJumpAnimation);
        Dialog loadingDialog = new Dialog(context, R.style.loadingDialog);
        loadingDialog.setCancelable(true);
        loadingDialog.setContentView(layout, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        return loadingDialog;
    }
}

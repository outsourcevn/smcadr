package com.collalab.smartcheck.networking;

import android.support.annotation.Nullable;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * Created by VietMac on 2017-01-18.
 */

public interface ApiInterface {
    @POST("login")
    Call<String> login(@Query("phone") String phone, @Query("pass") String pass, @Query("key") String key);

    @POST("register")
    Call<String> registerAccount(@Query("email") String email, @Query("phone") String phone, @Query("pass") String pass, @Query("user_id") String user_id, @Query("ref_phone") String ref, @Query("key") String key);

    @POST("register")
    Call<String> updateAccount(@Query("name") String name, @Query("email") String email, @Query("phone") String phone, @Query("pass") String pass, @Query("user_id") String user_id, @Query("identify") String identify, @Query("address") String address, @Query("key") String key);

    @POST("check")
    Call<String> check(@Query("guid") String guid, @Query("user_id") String user_id, @Query("lon") double lng, @Query("lat") double lat, @Query("address") String address, @Query("key") String key, @Query("points") String point, @Query("os") int os);

    @GET("getInfoUser")
    Call<String> getUserInfo(@Query("user_id") String userInfo);

    @GET("getListVoucher")
    Call<String> getVoucherList();

    @GET("getVoucherOfUser")
    Call<String> getVoucherOfUser(@Query("user_id") String userId);

    @GET("getListVoucherDetail")
    Call<String> getVoucherDetail(@Query("id") String voucherId);

    @GET("getHistoryCheckOfUser")
    Call<String> getHistoryCheckOfUser(@Query("user_id") String userId);

    @GET("getListWinningOfUser")
    Call<String> getListWinningOfUser(@Query("user_id") String userId);

    @GET("getWinningDetail")
    Call<String> getWinningDetail(@Query("id") String winningId);

    @POST("transferVoucher")
    Call<String> transferVoucher(@Query("user_id") String userId, @Query("voucher_id") String voucherId, @Query("points") String point, @Query("lon") String lng, @Query("lat") String lat, @Query("address") String address, @Query("key") String key);

    @POST("bonusPoints")
    Call<String> bonusPoints(@Query("user_id") String userId, @Query("type") String type, @Query("points") String point);

    @POST("getConfigPoints")
    Call<String> getConfigPoints();


}
package com.collalab.smartcheck.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.collalab.smartcheck.R;
import com.collalab.smartcheck.activity.VoucherDetailActivity;
import com.collalab.smartcheck.adapter.TransferVoucherAdapter;
import com.collalab.smartcheck.adapter.VoucherAdapter;
import com.collalab.smartcheck.common.IntentKey;
import com.collalab.smartcheck.listener.OnChangePointListener;
import com.collalab.smartcheck.model.RequestResponse;
import com.collalab.smartcheck.model.TransferVoucher;
import com.collalab.smartcheck.networking.ApiClient;
import com.collalab.smartcheck.networking.ApiInterface;
import com.collalab.smartcheck.persistence.PreferenceUtils;
import com.collalab.smartcheck.persistence.PrefsKey;
import com.collalab.smartcheck.utils.DataParser;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MyRewardFragment extends Fragment {

    ArrayList<TransferVoucher> mListTransferVoucher;
    ApiInterface apiService;

    @BindView(R.id.recycler_view)
    RecyclerView mRecyclerView;
    @BindView(R.id.progress_bar)
    ProgressBar mProgressBar;
    @BindView(R.id.siwpe_layout)
    SwipeRefreshLayout mSwipeRefreshLayout;
    @BindView(R.id.layout_empty)
    View mEmptyMyRewardView;

    TransferVoucherAdapter mVoucherAdapter;
    private GridLayoutManager mGridLayoutManager;

    String mUserId;

    private boolean isOnResumed;

    public MyRewardFragment() {

    }

    OnChangePointListener mOnChangePointListener;

    public void setOnChangePointListener(OnChangePointListener onChangePointListener) {
        this.mOnChangePointListener = onChangePointListener;
    }

    public static VoucherListFragment newInstance() {
        VoucherListFragment fragment = new VoucherListFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        PreferenceUtils.init(getActivity());
        apiService = ApiClient.getClient().create(ApiInterface.class);
        mUserId = PreferenceUtils.getString(PrefsKey.KEY_USER_ID, null);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_voucher_list, container, false);
        ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mGridLayoutManager = new GridLayoutManager(getContext(), 2);
        mVoucherAdapter = new TransferVoucherAdapter(getContext(), mListTransferVoucher);
        mVoucherAdapter.setOnVoucherItemListener(mOnVoucherItemListener);
        mRecyclerView.setAdapter(mVoucherAdapter);
        mRecyclerView.setLayoutManager(mGridLayoutManager);
        mRecyclerView.setHasFixedSize(true);

        setUpSwipeToRefreshLayout();

        getVoucherList_Network();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!isOnResumed) {
            isOnResumed = true;
            if (getUserVisibleHint()) {
                getVoucherList_Network();
            }
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        if (isVisibleToUser && isOnResumed) {
            getVoucherList_Network();
        }
    }

    private void getVoucherList_Network() {


        if (!mSwipeRefreshLayout.isRefreshing()) {
            mProgressBar.setVisibility(View.VISIBLE);
        }

        Call<String> call = apiService.getVoucherOfUser(mUserId);
        call.enqueue(mMyRewardListener);
    }

    Callback<String> mMyRewardListener = new Callback<String>() {
        @Override
        public void onResponse(Call<String> call, Response<String> response) {
            RequestResponse requestResponse = DataParser.getResponse(response.body());
            if (requestResponse.isSuccess()) {
                mListTransferVoucher = DataParser.parseTransferVoucherList(response.body());
                bindVoucherListViews();
            } else {
                Toast.makeText(getContext(), requestResponse.getMessage(), Toast.LENGTH_SHORT).show();
            }
            hideLoadingIndicator();
        }

        @Override
        public void onFailure(Call<String> call, Throwable t) {
            hideLoadingIndicator();
        }
    };

    TransferVoucherAdapter.OnVoucherItemListener mOnVoucherItemListener = new TransferVoucherAdapter.OnVoucherItemListener() {
        @Override
        public void onClick(int position) {
            Intent intent = new Intent(getContext(), VoucherDetailActivity.class);
            intent.putExtra(IntentKey.KEY_VOUCHER_ID, String.valueOf(mListTransferVoucher.get(position).getVoucherId()));
            intent.putExtra(IntentKey.KEY_TRANSFER_VOUCHER, mListTransferVoucher.get(position));
            startActivity(intent);
        }

        @Override
        public void onBuy(int position) {

        }
    };

    private void hideLoadingIndicator() {
        if (mSwipeRefreshLayout.isRefreshing()) {
            mSwipeRefreshLayout.setRefreshing(false);
        } else {
            mProgressBar.setVisibility(View.GONE);
        }
    }

    private void bindVoucherListViews() {
        if (mListTransferVoucher != null && mListTransferVoucher.size() > 0) {
            mVoucherAdapter.setVoucherList(mListTransferVoucher);
            mEmptyMyRewardView.setVisibility(View.GONE);
        } else {
            mEmptyMyRewardView.setVisibility(View.VISIBLE);
        }
    }

    private void setUpSwipeToRefreshLayout() {
        mSwipeRefreshLayout.setColorSchemeColors(ContextCompat.getColor(getContext(), R.color.color_actionbar));
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getVoucherList_Network();
            }
        });
    }

}

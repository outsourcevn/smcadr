package com.collalab.smartcheck.dialog;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.collalab.smartcheck.R;
import com.collalab.smartcheck.model.Transfer;
import com.collalab.smartcheck.model.UserInfo;
import com.collalab.smartcheck.model.Voucher;
import com.collalab.smartcheck.utils.SingleMediaScanner;
import com.collalab.smartcheck.utils.StringStyleUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;

/**
 * Created by VietMac on 2017-10-03.
 */

public class TransferSuccessDialog {

    private Context mContext;
    private Dialog dialog;
    private TextView tvCreatedFor;
    private View btnSaveVoucherCode;
    Voucher mVoucher;
    Transfer mTransfer;
    UserInfo mUserInfo;

    View mVoucherInfoLayout;
    TextView mTvVoucherCode;
    ProgressDialog mProgressDialog;


    public TransferSuccessDialog(Context mContext, final Voucher voucher, final Transfer transfer, final UserInfo userInfo) {
        this.mContext = mContext;

        mVoucher = voucher;
        mTransfer = transfer;
        mUserInfo = userInfo;

        dialog = new Dialog(mContext);
        dialog.getWindow().getAttributes().windowAnimations = R.style.SucessDialogAnimation;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.setContentView(R.layout.layout_transfer_success);
        dialog.setCanceledOnTouchOutside(false);

        mProgressDialog = new ProgressDialog(mContext);
        mProgressDialog.setMessage(mContext.getResources().getString(R.string.string_saving));

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        dialog.getWindow().setAttributes(lp);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        tvCreatedFor = (TextView) dialog.findViewById(R.id.tv_created_for);
        btnSaveVoucherCode = dialog.findViewById(R.id.btn_send_email_confirmation);

        mVoucherInfoLayout = dialog.findViewById(R.id.layout_voucher_info);
        mTvVoucherCode = (TextView) dialog.findViewById(R.id.tv_voucher_code);

        btnSaveVoucherCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnSaveVoucherCode.setEnabled(false);
                mProgressDialog.show();
                doSaveVoucherImage();
                mProgressDialog.dismiss();
                dialog.dismiss();
                btnSaveVoucherCode.setEnabled(true);
            }
        });

        init();
    }

    private void doSaveVoucherImage() {
        mVoucherInfoLayout.setDrawingCacheEnabled(true);
        mVoucherInfoLayout.buildDrawingCache();
        Bitmap bitmap = Bitmap.createBitmap(mVoucherInfoLayout.getDrawingCache());
        mVoucherInfoLayout.setDrawingCacheEnabled(false);

        saveImage(bitmap);
    }

    private void saveImage(Bitmap finalBitmap) {

        String root = Environment.getExternalStorageDirectory().getAbsolutePath();
        File myDir = new File(root + "/smartcheck_voucher");

        if (!myDir.exists()) {
            myDir.mkdirs();
        }

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss", Locale.US);
        Date now = new Date();
        String fileName = formatter.format(now) + ".jpg";
        File file = new File(myDir, fileName);
        if (file.exists()) file.delete();
        try {
            FileOutputStream out = new FileOutputStream(file);
            finalBitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
            out.flush();
            out.close();

            Toast.makeText(mContext, mContext.getResources().getString(R.string.string_save_voucher_success), Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            e.printStackTrace();
        }

        new ReloadMediaFile().execute(file.getAbsolutePath());

    }

    private void init() {
        mTvVoucherCode.setText(mTransfer.getCode());
        tvCreatedFor.setText(StringStyleUtils.getTransferSuccessStr(mContext, mUserInfo, mVoucher));
    }

    public void show() {
        if (dialog != null && !dialog.isShowing()) {
            dialog.show();
        }
    }

    public void dismiss() {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
    }

    class ReloadMediaFile extends AsyncTask {
        @Override
        protected Object doInBackground(Object[] params) {

            MediaScannerConnection.scanFile(mContext, new String[]{(String) params[0]}, new String[]{"image/jpg"}, null);

            return null;
        }
    };

}

package com.collalab.smartcheck.utils;

import android.text.TextUtils;

import com.google.zxing.common.StringUtils;

import java.util.UUID;

/**
 * Created by laptop88 on 8/30/2017.
 */

public class CollaLabUtils {
    public static boolean isGUID(String src) {
        try {
            UUID.fromString(src);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static String checkAndGetUUID(String src) {
        if (TextUtils.isEmpty(src)) {
            return null;
        }

        if (src.length() < 36) {
            return null;
        }

        for (int i = 0; i < src.length() - 36; i++) {
            String candidate = src.substring(i, i + 36);
            if (isGUID(candidate))
                return candidate;
        }
        return null;
    }
}

package com.collalab.smartcheck.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.collalab.smartcheck.R;
import com.collalab.smartcheck.model.Prize;
import com.collalab.smartcheck.model.ProductScan;
import com.collalab.smartcheck.utils.DateTimeUtils;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PrizeAdapter extends RecyclerView.Adapter<PrizeAdapter.VoucherViewHolder> {

    private List<Prize> mPrizeList;
    private Context mContext;
    NumberFormat mCurrencyFormatter;

    public void setOnPrizeItemListener(OnPrizeItemListener onPrizeItemListener) {
        this.onPrizeItemListener = onPrizeItemListener;
    }

    OnPrizeItemListener onPrizeItemListener;

    public interface OnPrizeItemListener {
        void onClick(int position);
    }

    public class VoucherViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.tv_gift_name)
        TextView textGiftName;
        @BindView(R.id.tv_address)
        TextView textAddress;
        @BindView(R.id.tv_prize_price)
        TextView textPricePrize;
        @BindView(R.id.tv_date)
        TextView textScanDate;

        public VoucherViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }
    }

    public PrizeAdapter(Context context, List<Prize> productScan) {
        this.mContext = context;
        this.mPrizeList = productScan;
        mCurrencyFormatter = new DecimalFormat("#,###");
    }

    @Override
    public VoucherViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_prize_item, parent, false);

        return new VoucherViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(VoucherViewHolder holder, final int position) {

        Prize prize = mPrizeList.get(position);

        if (!TextUtils.isEmpty(prize.getWinningName())) {
            holder.textGiftName.setText(prize.getWinningName());
        }

        if (!TextUtils.isEmpty(prize.getAddress())) {
            holder.textAddress.setText(String.format(mContext.getResources().getString(R.string.string_scan_at_address), prize.getAddress()));
        } else {
            holder.textAddress.setText(mContext.getResources().getString(R.string.string_unknown));
        }

        if (!TextUtils.isEmpty(prize.getDateTime())) {
            holder.textScanDate.setText(String.format(mContext.getString(R.string.string_scan_at_time), DateTimeUtils.getScannedDateFormattedStr(prize.getDateTime())));
        } else {
            holder.textScanDate.setText(mContext.getResources().getString(R.string.string_unknown));
        }

        if (!TextUtils.isEmpty(prize.getMoney()) && TextUtils.isDigitsOnly(prize.getMoney())) {
            String formattedPrice = mCurrencyFormatter.format(Double.valueOf(prize.getMoney()));
            holder.textPricePrize.setText(String.format(mContext.getString(R.string.string_wining_price), formattedPrice));
        } else {
            holder.textPricePrize.setText(String.format(mContext.getString(R.string.string_wining_price), "0"));
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onPrizeItemListener != null) {
                    onPrizeItemListener.onClick(position);
                }
            }
        });

    }

    public void setPrizeList(List<Prize> prizeList) {
        this.mPrizeList = prizeList;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return mPrizeList == null ? 0 : mPrizeList.size();
    }
}